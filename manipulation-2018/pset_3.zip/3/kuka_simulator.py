# %%
import numpy as np
import os

from pydrake.common import FindResourceOrThrow
from pydrake.geometry import SceneGraph
from pydrake.multibody.multibody_tree import (UniformGravityFieldElement,
                                              WeldJoint, )
from pydrake.multibody.multibody_tree.multibody_plant import MultibodyPlant
from pydrake.multibody.multibody_tree.parsing import AddModelFromSdfFile
from pydrake.systems.framework import DiagramBuilder
from pydrake.systems.analysis import Simulator
from pydrake.util.eigen_geometry import Isometry3
from pydrake.math import RollPitchYaw, RotationMatrix

from pydrake.systems.primitives import SignalLogger
from kuka_multibody_controllers import (RobotMultibodyController,
                                        HandController,
                                        ManipStateMachine)

from underactuated.meshcat_visualizer import MeshcatVisualizer

def ForwardKinematicsMbp(x, frame, mbp):
    assert len(x) == mbp.num_positions() + mbp.num_velocities()
    context = mbp.CreateDefaultContext()
    tree = mbp.tree()
    x_mutalbe = tree.get_mutable_multibody_state_vector(context)
    x_mutalbe[:] = x
    world_frame = mbp.world_frame()
    X_WE = tree.CalcRelativeTransform(
        context, frame_A=world_frame, frame_B=frame)
    return X_WE


def RenderSystemWithGraphviz(system, output_file="system_view.gz"):
    ''' Renders the Drake system (presumably a diagram,
    otherwise this graph will be fairly trivial) using
    graphviz to a specified file. '''
    from graphviz import Source
    string = system.GetGraphvizString()
    src = Source(string)
    src.render(output_file, view=False)


class KukaSimulator:
    def __init__(self, time_step=0.0002):
        # initial poses for apple and box
        self.table_top_z_in_world = 0.736 + 0.057 / 2
        self.X_WObject = Isometry3.Identity()
        self.X_WObject.set_translation([0.7, -0.2, self.table_top_z_in_world])

        # cupboard to world
        self.X_WC = Isometry3.Identity()
        self.X_WC.set_translation([1.0, 0.225, self.table_top_z_in_world + 0.125 + 0.001])
        self.X_WC.set_rotation(RollPitchYaw(np.pi / 2 * 3, 0, np.pi).ToRotationMatrix().matrix())

        self.CreateMultiBodyPlant(time_step)

    def get_multibody_plant(self):
        return self.plant

    def CreateMultiBodyPlant(self, time_step):
        iiwa_sdf_path = FindResourceOrThrow(
            "drake/manipulation/models/iiwa_description/"
            "sdf/iiwa14_no_collision.sdf")
        wsg50_sdf_path = FindResourceOrThrow(
            "drake/manipulation/models/"
            "wsg_50_description/sdf/schunk_wsg_50.sdf")
        table_sdf_path = FindResourceOrThrow(
            "drake/examples/kuka_iiwa_arm/models/table/"
            "extra_heavy_duty_table_surface_only_collision.sdf")
        object_sdf_path = os.path.join(os.getcwd(),
                                       "models", "box_for_pick_up.sdf")
        cupboard_sdf_path = os.path.join(
            os.getcwd(), "models", "cupboard.sdf")

        # construct multibodyplant
        plant = MultibodyPlant(time_step)
        scene_graph = SceneGraph()

        # Add models
        self.iiwa_model = AddModelFromSdfFile(
            file_name=iiwa_sdf_path, model_name='robot',
            scene_graph=scene_graph, plant=plant)
        self.gripper_model = AddModelFromSdfFile(
            file_name=wsg50_sdf_path, model_name='gripper',
            scene_graph=scene_graph, plant=plant)
        self.table_model = AddModelFromSdfFile(
            file_name=table_sdf_path, model_name='table',
            scene_graph=scene_graph, plant=plant)
        self.table2_model = AddModelFromSdfFile(
            file_name=table_sdf_path, model_name='table2',
            scene_graph=scene_graph, plant=plant)
        self.object_model = AddModelFromSdfFile(
            file_name=object_sdf_path, model_name='object',
            scene_graph=scene_graph, plant=plant)
        cupboard_model = AddModelFromSdfFile(
            file_name=cupboard_sdf_path, model_name='cupboard',
            scene_graph=scene_graph, plant=plant)

        # Define weld(fixed) joints
        X_Link7Ee = Isometry3.Identity()
        X_Link7Ee.set_translation([0, 0, 0.081])
        X_Link7Ee.set_rotation(RollPitchYaw(np.pi / 2, 0, np.pi / 2).ToRotationMatrix().matrix())


        # weld_gripper_to_robot_ee
        plant.WeldFrames(
            A=plant.GetFrameByName("iiwa_link_7", self.iiwa_model),
            B=plant.GetFrameByName("body", self.gripper_model),
            X_AB=X_Link7Ee)

        # weld_table_to_world
        plant.WeldFrames(
            A=plant.world_frame(),
            B=plant.GetFrameByName("link", self.table_model))

        # weld_robot_to_world
        X_WRobot = Isometry3.Identity()
        X_WRobot.set_translation([0, 0, self.table_top_z_in_world])
        plant.WeldFrames(
            A=plant.world_frame(),
            B=plant.GetFrameByName("iiwa_link_0", self.iiwa_model),
            X_AB=X_WRobot)

        # weld_table2_to_world
        X_WTable2 = Isometry3.Identity()
        X_WTable2.set_translation([0.8, 0, 0])
        plant.WeldFrames(
            A=plant.world_frame(),
            B=plant.GetFrameByName("link", self.table2_model),
            X_AB=X_WTable2)

        # weld cupboard to world
        plant.WeldFrames(
            A=plant.world_frame(),
            B=plant.GetFrameByName("bottom", cupboard_model),
            X_AB=self.X_WC)


        # Add gravity
        plant.AddForceElement(UniformGravityFieldElement([0, 0, -9.81]))

        plant.Finalize(scene_graph)
        assert plant.geometry_source_is_registered()

        self.plant = plant
        self.scene_graph = scene_graph


    def RunSimulation(self, plans_list, gripper_setpoint_list, extra_time = 0,
                      is_test=False, real_time_rate=1.0):
        if not is_test:
            print "Warning: if you have not yet run meshcat-server in another " \
                  "terminal, this will hang."

        builder = DiagramBuilder()
        scene_graph = builder.AddSystem(self.scene_graph)
        plant = builder.AddSystem(self.plant)

        # Add meshcat visualizer if not in test mode
        viz = None
        if not is_test:
            viz = MeshcatVisualizer(scene_graph)
            builder.AddSystem(viz)
            builder.Connect(scene_graph.get_pose_bundle_output_port(),
                            viz.get_input_port(0))

        # Connect scene_graph to MBP for collision detection.
        builder.Connect(
            plant.get_geometry_poses_output_port(),
            scene_graph.get_source_pose_port(plant.get_source_id()))
        builder.Connect(
            scene_graph.get_query_output_port(),
            plant.get_geometry_query_input_port())

        # Add iiwa controller
        print_period = 0.5
        if is_test:
            print_period = 0.0
        iiwa_controller = RobotMultibodyController(plant=plant,
                                                   robot_model_instance=self.iiwa_model,
                                                   print_period=print_period)
        builder.AddSystem(iiwa_controller)
        builder.Connect(iiwa_controller.get_output_port(0),
                        plant.get_input_port(0))
        builder.Connect(plant.get_continuous_state_output_port(),
                        iiwa_controller.robot_state_input_port)
        builder.Connect(plant.get_contact_results_output_port(),
                        iiwa_controller.contact_results_input_port)

        # Add hand controller
        hand_controller = HandController(plant=plant,
                                         model_instance=self.gripper_model)
        builder.AddSystem(hand_controller)
        builder.Connect(hand_controller.get_output_port(0),
                        plant.get_input_port(1))
        builder.Connect(plant.get_continuous_state_output_port(),
                        hand_controller.robot_state_input_port)

        # Add state machine
        state_machine = ManipStateMachine(plant, plans_list, gripper_setpoint_list)
        builder.AddSystem(state_machine)
        builder.Connect(plant.get_continuous_state_output_port(),
                        state_machine.robot_state_input_port)
        builder.Connect(state_machine.kuka_plan_output_port,
                        iiwa_controller.plan_input_port)
        builder.Connect(state_machine.hand_setpoint_output_port,
                        hand_controller.setpoint_input_port)

        # Add logger
        state_log = builder.AddSystem(SignalLogger(plant.get_continuous_state_output_port().size()))
        state_log._DeclarePeriodicPublish(0.02)
        builder.Connect(plant.get_continuous_state_output_port(), state_log.get_input_port(0))

        # Build diagram.
        diagram = builder.Build()
        if not is_test:
            viz.load()

        # generate system diagram using graphviz if not in test mode
        if not is_test:
            RenderSystemWithGraphviz(diagram, "view.gv")

        # Create simulation diagram context
        diagram_context = diagram.CreateDefaultContext()
        mbp_context = diagram.GetMutableSubsystemContext(
            plant, diagram_context)

        # fix cupboard actuation input to 0
        mbp_context.FixInputPort(
            plant.get_input_port(2).get_index(),
            np.zeros(plant.get_input_port(2).size()))

        # set initial pose for the object and the box.
        tree = plant.tree()
        tree.SetFreeBodyPoseOrThrow(
            plant.GetBodyByName("base_link_box", self.object_model), self.X_WObject, mbp_context)

        # set initial posture of the iiwa arm.
        q0 = plans_list[0].traj.value(0)
        for i, joint_angle in enumerate(q0):
            iiwa_joint = plant.GetJointByName("iiwa_joint_%d" % (i + 1))
            iiwa_joint.set_angle(context=mbp_context, angle=joint_angle)

        simulator = Simulator(diagram, diagram_context)
        simulator.set_publish_every_time_step(False)
        simulator.set_target_realtime_rate(real_time_rate)
        simulator.Initialize()

        sim_duration = 0.
        for plan in plans_list:
            sim_duration += plan.get_duration() * 1.1
        sim_duration += extra_time
        simulator.StepTo(sim_duration)

        return state_log




