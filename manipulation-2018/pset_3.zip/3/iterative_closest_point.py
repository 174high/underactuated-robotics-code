# Pset 2a: Iterative Closest Point
#Code adapted from Clay Flannigan
import numpy as np

import meshcat
import meshcat.geometry as g
import meshcat.transformations as tf

from sklearn.neighbors import NearestNeighbors

def make_meshcat_color_array(N, r, g, b):
    '''
    Construct a color array to visualize a point cloud in meshcat

    Args:
        N: int. number of points to generate. Must be >= number of points in the
            point cloud to color
        r: float. The red value of the points, 0.0 <= r <= 1.0
        g: float. The green value of the points, 0.0 <= g <= 1.0
        b: float. The blue value of the points, 0.0 <= b <= 1.0

    Returns:
        3xN numpy array of the same color
    '''
    color = np.zeros((3, N))
    color[0, :] = r
    color[1, :] = g
    color[2, :] = b

    return color


def visualize_icp(meshcat_vis, scene, model, X_MS):
    '''
    Visualize the ground truth (red), observation (blue), and transformed
    (yellow) point clouds in meshcat.

    Args:
        meschat_vis: an instance of a meshcat visualizer
        scene: an Nx3 numpy array representing scene point cloud
        model: an Mx3 numpy array representing model point cloud
        X_GO: 4x4 numpy array of the homogeneous transformation from the
            scene point cloud to the model point cloud.
    '''

    meshcat_vis['model'].delete()
    meshcat_vis['observations'].delete()
    meshcat_vis['transformed_observations'].delete()

    # Make meshcat color arrays.
    N = scene.shape[0]
    M = model.shape[0]

    red = make_meshcat_color_array(M, 0.5, 0, 0)
    blue = make_meshcat_color_array(N, 0, 0, 0.5)
    yellow = make_meshcat_color_array(N, 1, 1, 0)

    # Create red and blue meshcat point clouds for visualization.
    model_meshcat = g.PointCloud(model.T, red, size=0.01)
    observations_meshcat = g.PointCloud(scene.T, blue, size=0.01)

    # meshcat_vis['model'].set_object(model_meshcat)
    # meshcat_vis['observations'].set_object(observations_meshcat)

    # Create a copy of the scene point cloud that is homogenous
    # so we can apply a 4x4 homogenous transform to it.
    homogenous_scene = np.ones((N, 4))
    homogenous_scene[:, :3] = np.copy(scene)

    # Apply the returned transformation to the scene samples to align the
    # scene point cloud with the ground truth point cloud.
    transformed_scene = X_MS.dot(homogenous_scene.T)

    # Create a yellow meshcat point cloud for visualization.
    transformed_scene_meshcat = \
        g.PointCloud(transformed_scene[:3, :], yellow, size=0.001)

    meshcat_vis['transformed_observations'].set_object(
        transformed_scene_meshcat)


def clear_vis(meshcat_vis):
    '''
    Removes model, observations, and transformed_observations objects
    from meshcat.

    Args:
        meschat_vis: an instance of a meshcat visualizer
    '''

    meshcat_vis['model'].delete()
    meshcat_vis['observations'].delete()
    meshcat_vis['transformed_observations'].delete()


def nearest_neighbors(point_cloud_A, point_cloud_B):
    '''
    Find the nearest (Euclidean) neighbor in point_cloud_B for each
    point in point_cloud_A.

    Args:
        point_cloud_A: Nx3 numpy array of points
        point_cloud_B: Mx3 numpy array of points
    Returns:
        distances: (N, ) numpy array of Euclidean distances from each point in
            point_cloud_A to its nearest neighbor in point_cloud_B.
        indices: (N, ) numpy array of the indices in point_cloud_B of each
            point_cloud_A point's nearest neighbor - these are the c_i's
    '''

    distances = np.zeros(point_cloud_A.shape[1])
    indices = np.zeros(point_cloud_A.shape[1])

    # your code here
    ##################

    ##################

    return distances, indices


def least_squares_transform(point_cloud_A, point_cloud_B):
    '''
    Calculates the least-squares best-fit transform that maps corresponding
    points point_cloud_A to point_cloud_B.

    Args:
      point_cloud_A: Nx3 numpy array of corresponding points
      point_cloud_B: Nx3 numpy array of corresponding points
    Returns:
      X_BA: 4x4 numpy array of the homogeneous transformation matrix that maps
             point_cloud_A on to point_cloud_B such that

                        X_BA x point_cloud_Ah ~= point_cloud_B,

             where point_cloud_Ah is a homogeneous version of point_cloud_A
    '''

    # number of dimensions
    m = 3
    X_BA = np.identity(4)

    # your code here
    ##################

    ##################

    return X_BA

def icp(point_cloud_A, point_cloud_B,
        init_guess=None, max_iterations=20, tolerance=1e-3):
    '''
    The Iterative Closest Point algorithm: finds best-fit transform that maps
        point_cloud_A on to point_cloud_B

    Args:
        point_cloud_A: Nx3 numpy array of points to match to point_cloud_B
        point_cloud_B: Nx3 numpy array of points
        init_guess: 4x4 homogeneous transformation representing an initial guess
            of the transform. If one isn't provided, the 4x4 identity matrix
            will be used.
        max_iterations: int. if the algorithm hasn't converged after
            max_iterations, exit the algorithm
        tolerance: float. the maximum difference in the error between two
            consecutive iterations before stopping
    
    Returns:
        X_BA: 4x4 numpy array of the homogeneous transformation matrix that
            maps point_cloud_A on to point_cloud_B such that

                        X_BA x point_cloud_Ah ~= point_cloud_B,

            where point_cloud_Ah is a homogeneous version of point_cloud_A
        mean_error: float. mean of the Euclidean distances from each point in
            the transformed point_cloud_A to its nearest neighbor in
            point_cloud_B
        num_iters: int. total number of iterations run
    '''

    # Transform from point_cloud_B to point_cloud_A
    # Overwrite this with ICP results.
    X_BA = np.identity(4)

    mean_error = 0
    num_iters = 0


    # Number of dimensions
    m = 3

    # Make homogeneous copies of boht point clouds
    point_cloud_Ah = np.ones((4, point_cloud_A.shape[0]))
    point_cloud_Bh = np.ones((4, point_cloud_B.shape[0]))
    point_cloud_Ah[:m, :] = np.copy(point_cloud_A.T)
    point_cloud_Bh[:m, :] = np.copy(point_cloud_B.T)

    # your code here
    ##################

    ##################

    return X_BA, mean_error, num_iters


def repeat_icp_until_good_fit(point_cloud_A,
                              point_cloud_B,
                              error_threshold,
                              max_tries,
                              init_guess=None,
                              max_iterations=20,
                              tolerance=0.001):
    '''
    Run ICP until it converges to a "good" fit.

    Args:
        point_cloud_A: Nx3 numpy array of points to match to point_cloud_B
        point_cloud_B: Nx3 numpy array of points
        error_threshold: float. maximum allowed mean ICP error before stopping
        max_tries: int. stop running ICP after max_tries if it hasn't produced
            a transform with an error < error_threshold.
        init_guess: 4x4 homogeneous transformation representing an initial guess
            of the transform. If one isn't provided, the 4x4 identity matrix
            will be used.
        max_iterations: int. if the algorithm hasn't converged after
            max_iterations, exit the algorithm
        tolerance: float. the maximum difference in the error between two
            consecutive iterations before stopping

    Returns:
        X_BA: 4x4 numpy array of the homogeneous transformation matrix that
            maps point_cloud_A on to point_cloud_B such that

                        X_BA x point_cloud_Ah ~= point_cloud_B,

            where point_cloud_Ah is a homogeneous version of point_cloud_A
        mean_error: float. mean of the Euclidean distances from each point in
            the transformed point_cloud_A to its nearest neighbor in
            point_cloud_B
        num_runs: int. total number of times ICP ran - not the total number of
            ICP iterations.
    '''

    # Transform from point_cloud_B to point_cloud_A
    # Overwrite this with ICP results.
    X_BA = np.identity(4)

    mean_error = 1e8
    num_runs = 0

    # your code here
    ##################

    ##################

    return X_BA, mean_error, num_runs