import numpy as np
import sys
import pydrake
from pydrake.all import (
    BasicVector,
    LeafSystem,
    PortDataType,
    MathematicalProgram,
    AbstractValue,
)
from pydrake.util.eigen_geometry import Isometry3
from pydrake.trajectories import (
    PiecewisePolynomial
)

from pydrake.multibody.multibody_tree import MultibodyForces
from robot_plans import *


class RobotMultibodyController(LeafSystem):
    def __init__(self, plant, robot_model_instance,
                 control_period=0.005,
                 print_period=0.5):
        LeafSystem.__init__(self)
        self.set_name("Kuka Controller")

        #TODO: access actuation ports with model_instance
        robot_model_index_idx = 0
        self.nu = plant.get_input_port(robot_model_index_idx).size()

        self.plant = plant
        self.tree = plant.tree()
        self.print_period = print_period
        self.last_print_time = -print_period
        self.control_period = control_period
        self.model_instance = robot_model_instance

        self.nq = plant.num_positions()
        v_dummy = np.arange(plant.num_velocities())
        self.controlled_inds = self.tree.get_velocities_from_array(
            robot_model_instance, v_dummy).astype(int)


        self.robot_state_input_port = \
            self._DeclareInputPort(PortDataType.kVectorValued,
                                   plant.num_positions() +
                                   plant.num_velocities())
        self.plan_input_port = \
            self._DeclareInputPort(PortDataType.kAbstractValued, 0)
        self.contact_results_input_port = \
            self._DeclareInputPort(PortDataType.kAbstractValued, 0)

        self._DeclareDiscreteState(self.nu)
        self._DeclarePeriodicDiscreteUpdate(period_sec=control_period)
        self._DeclareVectorOutputPort(BasicVector(self.nu),
            self._DoCalcVectorOutput)

    def _DoCalcDiscreteVariableUpdates(self, context, events, discrete_state):
        # Call base method to ensure we do not get recursion.
        # (This makes sure relevant event handlers get called.)
        LeafSystem._DoCalcDiscreteVariableUpdates(
            self, context, events, discrete_state)

        new_control_input = discrete_state. \
            get_mutable_vector().get_mutable_value()
        t= context.get_time()
        x = self.EvalVectorInput(
            context, self.robot_state_input_port.get_index()).get_value()
        plan = self.EvalAbstractInput(
            context, self.plan_input_port.get_index()).get_value()
        contact_results = self.EvalAbstractInput(
            context, self.contact_results_input_port.get_index()).get_value()

        q = x[:self.nq]
        v = x[self.nq:]
        t_plan = t - plan.start_time
        tree = self.plant.tree()
        q_robot = tree.get_positions_from_array(self.model_instance, q)
        v_robot = tree.get_velocities_from_array(self.model_instance, v)
        context = self.plant.CreateDefaultContext()
        x_mutable = tree.get_mutable_multibody_state_vector(context)
        x_mutable[:] = x

        vDt_desired = np.zeros(self.plant.num_velocities())
        new_u = np.zeros(len(self.controlled_inds))

        if plan.type == "JointSpacePlan":
            # The desired joint angle and velocities at this time (t_plan)
            q_robot_ref = plan.traj.value(t_plan).flatten()
            v_robot_ref = plan.traj_d.value(t_plan).flatten()

            qerr_robot = (q_robot_ref - q_robot) # joint angle error
            verr_robot = (v_robot_ref - v_robot) # joint velocity error

            # Get the full LHS (joint accelerations) of the manipulator equations
            # given the current config and velocity errors.
            vDt_desired[self.controlled_inds] = 1000.*qerr_robot + 100*verr_robot

        tau = tree.CalcInverseDynamics(context=context,
                                       known_vdot=vDt_desired,
                                       external_forces=MultibodyForces(tree))
        new_u[:] = tau[self.controlled_inds]
        new_control_input[:] = new_u

    def TaskSpaceController(self, X_WE, X_WEr, Jv_WE_W, q_robot, v_robot):
        # X_WE: current EE pose relative to world
        # X_WEr: target EE pose specified by trajectory
        # Jv_WE_W: geometric Jacobian in world frame
        # q_robot: current joint angles
        # v_robot: current joint velocities
        
        def adjoint(R, p):
            # Maps twist given transform (R matrix, p translation)
            Ad = np.zeros((6, 6))
            Ad[0:3, 0:3] = R
            Ad[3:6, 3:6] = R
            p_tilt = np.array([[0, -p[2], p[1]], \
                               [p[2], 0, -p[1]], \
                               [-p[1], p[0], 0]])
            # Note that a twist in Drake is [omega | v] and so this is
            # transpose of what's in the Lecture notes.
            Ad[3:6, 0:3] = p_tilt.dot(R)
            return Ad

        def log_R(R):
            # Log map from SO(3) to so(3)
            # https://en.wikipedia.org/wiki/Axis%E2%80%93angle_representation
            phi = np.arccos(0.5 * (R.trace() - 1))
            if np.abs(phi) < 1e-6:
                phi_over_sin_phi = 1    # sin(phi) is approx phi for small phi
            else:
                phi_over_sin_phi = phi / np.sin(phi)
            log_matrix = 0.5 * phi_over_sin_phi * (R - R.T)
            log_vector = np.zeros(3)
            log_vector[0] = log_matrix[2, 1]
            log_vector[1] = log_matrix[0, 2]
            log_vector[2] = log_matrix[1, 0]
            return log_vector

        X_EW = X_WE.inverse() # inverse
        R_WE = X_WE.rotation() # rotation
        p_WE = X_WE.translation() # translation
        # Transforms a twist in the EE frame to world frame
        Ad_WE = adjoint(R_WE, p_WE) # see definition of Adjoint

        # The relative transform from current EE pose to desired
        # pose specified by trajectory.
        X_EEr = X_EW.multiply(X_WEr)
        R_EEr = X_EEr.rotation()    # rotation
        p_EEr = X_EEr.translation() # translation Computes angular
        # Velocity from rotation (SO(3) -> so(3)).  This is the
        # desired instantaneous velocity to track trajectory.
        log_R_EEr = log_R(R_EEr)

        # Compute desired twist (angular : linear)
        # kp is "gain" on error in task coordinates
        kp_rotation = np.full(3, 100)
        kp_translation = np.full(3, 200)
        # Desired end effector twist in end effector frame
        T_WE_E_des = np.zeros(6)
        T_WE_E_des[0:3] = kp_rotation * log_R_EEr # angular
        T_WE_E_des[3:6] = kp_translation * p_EEr  # translational

        # Transform twist from EE frame to world frame using Adjoint matrix
        T_WE_W_des = Ad_WE.dot(T_WE_E_des)
        # Use the (pseudo) inverse J to get joint velocities from twist
        qdot = np.linalg.pinv(Jv_WE_W).dot(T_WE_W_des)
        # Then, get desired joint angle change as qdot*dt=qerr
        qerr_robot = self.control_period * qdot

        # A joint space controller, note we estimate velocity from commands
        # The new (desired) joint vector, note we add to current joint angles
        q_kuka_commanded_new = q_robot + qerr_robot
        if self.q_kuka_commanded_previous is None:
            self.q_kuka_commanded_previous = q_kuka_commanded_new
        # The new (desired) velocity (mimics what's inside drake's iiwa_sim)
        v_robot_ref = (q_kuka_commanded_new - self.q_kuka_commanded_previous)/self.control_period
        verr_robot = v_robot_ref - v_robot

        # remember previous command
        self.q_kuka_commanded_previous = q_kuka_commanded_new

        # PD controller in joint coordinates, specifies desired joint acceleration
        return 300. * qerr_robot + 100. * verr_robot
        
    def _DoCalcVectorOutput(self, context, y_data):
        if (self.print_period and
                context.get_time() - self.last_print_time
                >= self.print_period):
            print "t: ", context.get_time()
            self.last_print_time = context.get_time()
        control_output = context.get_discrete_state_vector().get_value()
        y = y_data.get_mutable_value()
        # Get the ith finger control output
        y[:] = control_output[:]


class HandController(LeafSystem):
    def __init__(self, plant,
                 model_instance,
                 control_period=0.001):
        LeafSystem.__init__(self)
        self.set_name("Hand Controller")
        gripper_model_index_idx = 1

        self.max_force = 100.  # gripper max closing / opening force
        self.plant = plant
        self.model_instance = model_instance

        # TODO: access actuation ports with model_instance index
        self.nu = plant.get_input_port(gripper_model_index_idx).size()
        self.nq = plant.num_positions()

        self.robot_state_input_port = \
            self._DeclareInputPort(PortDataType.kVectorValued,
                                   plant.num_positions() +
                                   plant.num_velocities())

        self.setpoint_input_port = \
            self._DeclareInputPort(PortDataType.kVectorValued,
                                   1)

        self._DeclareDiscreteState(self.nu)
        self._DeclarePeriodicDiscreteUpdate(period_sec=control_period)
        self._DeclareVectorOutputPort(
            BasicVector(self.nu),
            self._DoCalcVectorOutput)

    def _DoCalcDiscreteVariableUpdates(self, context, events, discrete_state):
        # Call base method to ensure we do not get recursion.
        # (This makes sure relevant event handlers get called.)
        LeafSystem._DoCalcDiscreteVariableUpdates(
            self, context, events, discrete_state)

        new_control_input = discrete_state. \
            get_mutable_vector().get_mutable_value()
        x = self.EvalVectorInput(
            context, self.robot_state_input_port.get_index()).get_value()

        gripper_width_des = self.EvalVectorInput(
            context, self.setpoint_input_port.get_index()).get_value()

        q_full = x[:self.nq]
        v_full = x[self.nq:]
        tree = self.plant.tree()
        q_hand = tree.get_positions_from_array(self.model_instance, q_full)
        q_hand_des = np.array([-gripper_width_des[0], gripper_width_des[0]])
        v_hand = tree.get_velocities_from_array(self.model_instance, v_full)
        v_hand_des = np.zeros(2)

        qerr_hand = q_hand_des - q_hand
        verr_hand = v_hand_des - v_hand

        Kp = 1000.
        Kv = 100.
        new_control_input[:] = np.clip(
            Kp * qerr_hand + Kv * verr_hand, -self.max_force, self.max_force)

    def _DoCalcVectorOutput(self, context, y_data):
        control_output = context.get_discrete_state_vector().get_value()
        y = y_data.get_mutable_value()
        # Get the ith finger control output
        y[:] = control_output[:]


class ManipStateMachine(LeafSystem):
    '''
    Encodes the high-level logic for the manipulation system.

    This state machine receives a list of Plans, and sends them to
    the robot in a chronological order. Each trajectory is live through
    the system's kuka_plan_output_port for
    (kuka_plans[i].duration() + 0.5) seconds, after which kuka_plans[i+1]
    will become live.
    '''
    def __init__(self, plant, kuka_plans, gripper_setpoint_list):
        LeafSystem.__init__(self)
        self.set_name("Manipulation State Machine")

        assert len(kuka_plans) == len(gripper_setpoint_list)
        self.gripper_setpoint_list = gripper_setpoint_list
        self.kuka_plans_list = kuka_plans

        self.num_plans = len(kuka_plans)
        self.t_plan = np.zeros(self.num_plans + 1)
        for i in range(self.num_plans):
            self.t_plan[i + 1] = \
                self.t_plan[i] + kuka_plans[i].get_duration() * 1.1

        self.current_plan_idx = 0
        self.current_plan =kuka_plans[0]
        self.current_plan.set_start_time(0.)

        self.nq = plant.num_positions()
        self.plant = plant

        self.robot_state_input_port = \
            self._DeclareInputPort(PortDataType.kVectorValued,
                                   plant.num_positions() +
                                   plant.num_velocities())

        self._DeclareDiscreteState(1)
        self._DeclarePeriodicDiscreteUpdate(period_sec=0.01)
        self.kuka_plan_output_port = \
            self._DeclareAbstractOutputPort(
                lambda: AbstractValue.Make(PlanBase()), self.GetCurrentPlan)
        self.hand_setpoint_output_port = \
            self._DeclareVectorOutputPort(
                BasicVector(1), self._DoCalcHandSetpointOutput)


    def _DoCalcDiscreteVariableUpdates(self, context, events, discrete_state):
        # Call base method to ensure we do not get recursion.
        LeafSystem._DoCalcDiscreteVariableUpdates(
            self, context, events, discrete_state)

        new_state = discrete_state. \
            get_mutable_vector().get_mutable_value()
        # Close gripper after plan has been executed
        new_state[:] = self.gripper_setpoint_list[self.current_plan_idx]

    def GetCurrentPlan(self, context, y_data):
        t = context.get_time()
        x = self.EvalVectorInput(
            context, self.robot_state_input_port.get_index()).get_value()
        q = x[:self.nq]
        v = x[self.nq:]

        new_plan_idx = 0
        for i in range(self.num_plans):
            if t >= self.t_plan[i] and t < self.t_plan[i + 1]:
                new_plan_idx = i
                break
        if self.current_plan_idx < new_plan_idx:
            self.current_plan_idx = new_plan_idx
            self.current_plan = self.kuka_plans_list[new_plan_idx]
            self.current_plan.set_start_time(t)
            # print "switching to new plan at %f"%t

        y_data.set_value(self.current_plan)


    def _DoCalcHandSetpointOutput(self, context, y_data):
        state = context.get_discrete_state_vector().get_value()
        y = y_data.get_mutable_value()
        # Get the ith finger control output
        y[:] = state[0]


