import numpy as np
from pydrake.multibody import inverse_kinematics
from pydrake.trajectories import (
    PiecewisePolynomial
)
from pydrake.util.eigen_geometry import Isometry3
from pydrake.math import RollPitchYaw, RotationMatrix

from kuka_simulator import KukaSimulator, ForwardKinematicsMbp
from kuka_multibody_controllers import *


'''
Ea, or End_Effector_world_aligned is a frame fixed w.r.t the gripper.
Ea has the same origin as the end effector's body frame, but
its axes are aligned with those of the world frame when the system
has zero state, i.e. the robot is upright with all joint angles
equal to zero.

This frame is defined so that it is convenient to define end effector orientation
relative to the world frame using RollPitchYaw.
'''
def GetEndEffectorWorldAlignedFrame():
    X_EEa = Isometry3.Identity()
    X_EEa.set_rotation(np.array([[0., 1., 0,],
                                 [0, 0, 1],
                                 [1, 0, 0]]))
    return X_EEa

# home position of point Q in world frame.
p_WQ_home = np.array([0.6, 0, 1.0])

# position of point Q in EE frame.  Point Q is fixed in the EE frame.
p_EQ = GetEndEffectorWorldAlignedFrame().multiply(np.array([0., 0., 0.09]))


def GenerateIiwaPlansAndGripperSetPoints(kuka_simulator, is_printing=True):
    # position of hinge in world frame
    p_center = kuka_simulator.X_WC.translation() + [-0.125, -0.025, 0]

    # distance between hinge axis and center of door handle
    r_door = np.sqrt(0.06 ** 2 + 0.20 ** 2)

    iiwa_model = kuka_simulator.iiwa_model
    gripper_model = kuka_simulator.gripper_model

    plant = kuka_simulator.get_multibody_plant()
    X_WObject = kuka_simulator.X_WObject
    tree = plant.tree()

    # get first pre-pre-grasp pose
    ik_scene = inverse_kinematics.InverseKinematics(plant)
    world_frame = plant.world_frame()
    gripper_frame = plant.GetFrameByName("body", gripper_model)

    theta_bound = 0.01 * np.pi
    X_EEa = GetEndEffectorWorldAlignedFrame()
    R_WEa_ref = RollPitchYaw(0, np.pi*3/4, 0).ToRotationMatrix()
    R_EEa = RotationMatrix(X_EEa.rotation())

    ik_scene.AddOrientationConstraint(
        frameAbar=world_frame, R_AbarA=R_WEa_ref,
        frameBbar=gripper_frame, R_BbarB=R_EEa,
        theta_bound=theta_bound)

    p_WQ_lower = p_WQ_home - 0.01
    p_WQ_upper = p_WQ_home + 0.01
    ik_scene.AddPositionConstraint(
        frameB=gripper_frame, p_BQ=p_EQ,
        frameA=world_frame,
        p_AQ_lower=p_WQ_lower, p_AQ_upper=p_WQ_upper)

    prog = ik_scene.prog()
    prog.SetInitialGuess(ik_scene.q(), np.zeros(plant.num_positions()))
    result = prog.Solve()
    if is_printing:
        print result
    q_val_0 = prog.GetSolution(ik_scene.q())

    # q returned by IK consists of the configuration of all bodies, including
    # the iiwa arm, the box, the gripper and the bottle.
    # But the trajectory sent to iiwa only needs the configuration of iiwa.
    # This function takes in an array of shape (n, plant.num_positions()),
    # and returns an array of shape (n, 7), which only has the configuration of the iiwa arm.
    def GetKukaQKnots(q_knots):
        if len(q_knots.shape) == 1:
            q_knots.resize(1, q_knots.size)
        n = q_knots.shape[0]
        q_knots_kuka = np.zeros((n, 7))
        for i, q_knot in enumerate(q_knots):
            q_knots_kuka[i] = tree.get_positions_from_array(iiwa_model, q_knot)

        return q_knots_kuka

    # 0 to home
    t_knots = np.array([0., 0.5, 1.0])
    q_knots_kuka = np.zeros((3,7))
    q_knots_kuka[2] = GetKukaQKnots(q_val_0)
    q_knots_kuka[1] = (q_knots_kuka[0] + q_knots_kuka[2])/2

    qtraj_go_home = PiecewisePolynomial.Cubic(
        t_knots, q_knots_kuka.T,
        np.zeros(7), np.zeros(7))

    # your code here
    ####################

    ####################
    q_traj_list = [qtraj_go_home]

    plan_list = []
    for q_traj in q_traj_list:
        plan_list.append(JointSpacePlan(q_traj))

    gripper_setpoint_list = [0.05]
    return plan_list, gripper_setpoint_list


if __name__ == '__main__':
    kuka_simulator = KukaSimulator()
    plan_list, gripper_setpoint_list = \
        GenerateIiwaPlansAndGripperSetPoints(kuka_simulator)

    state_log = \
        kuka_simulator.RunSimulation(plan_list, gripper_setpoint_list)
