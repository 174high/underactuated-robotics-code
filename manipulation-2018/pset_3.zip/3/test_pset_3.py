import os
import sys
import timeout_decorator
import unittest
import numpy as np
from gradescope_utils.autograder_utils.decorators import weight
from gradescope_utils.autograder_utils.json_test_runner import JSONTestRunner


class TestPset3_PointCloudRegistrationTest(unittest.TestCase):

    @weight(2)
    @timeout_decorator.timeout(2.0)
    def test_00_spatula_segmentation(self):
        '''the spatula is segmented correctly'''
        from realsense_point_cloud_registration import segment_spatula

        spatula_scene_points = np.load('./point_clouds/scenes/spatula_points.npy')
        spatula_scene_colors = np.load('./point_clouds/scenes/spatula_colors.npy')

        segmented_spatula_points, segmented_spatula_colors = \
        segment_spatula(spatula_scene_points, spatula_scene_colors)

        num_points = segmented_spatula_points.shape[0]

        self.assertTrue(15000 < num_points and num_points < 20000,
                        "Your cluster has %d points. The spatula cluster should "
                        "have 15000~20000 points" % num_points )

        spatula_centroid = np.array([-0.604, 0.089, 0.016])

        self.assertTrue(
            np.linalg.norm(
                np.mean(segmented_spatula_points, axis=0) - spatula_centroid) < 0.2,
            "The mean of your segmented point_cloud is too far away from where the "
            "spatula is.")

    @weight(2)
    @timeout_decorator.timeout(2.0)
    def test_01_drill_segmentation(self):
        '''the drill is segmented correctly'''
        from realsense_point_cloud_registration import segment_drill

        drill_scene_points = np.load('./point_clouds/scenes/drill_points.npy')
        drill_scene_colors = np.load('./point_clouds/scenes/drill_colors.npy')

        segmented_drill_points, segmented_drill_colors = \
        segment_drill(drill_scene_points, drill_scene_colors)

        num_points = segmented_drill_points.shape[0]

        self.assertTrue(13000 < num_points and num_points < 18000,
                        "Your cluster has %d points. The drill cluster should "
                        "have 13000~18000 points" % num_points )

        drill_centroid = np.array([-0.633, 0.128, 0.043])

        self.assertTrue(
            np.linalg.norm(
                np.mean(segmented_drill_points, axis=0) - drill_centroid) < 0.2,
            "The mean of your segmented point_cloud is too far away from where the "
            "drill is.")

    @weight(5)
    @timeout_decorator.timeout(20.0)
    def test_02_perfect_spatula_alignment(self):
        '''the perfect spatula aligns with the model'''
        from realsense_point_cloud_registration import (align_scene_to_model,
                                                        transform_to_pose)

        model = np.load('./point_clouds/models/spatula_model.npy')
        scene = np.load('./point_clouds/scenes/spatula_model_transformed.npy')

        X_MS, error = align_scene_to_model(scene, model)

        true_th = -np.pi/6
        true_x = -0.1
        true_y = -0.1

        tolerance = 1e-2

        opt_x, opt_y, opt_sin_th, opt_cos_th = transform_to_pose(X_MS)

        self.assertLess(abs(opt_x - true_x), tolerance,
                      "The returned x = %f is not close to x = %f"
                      % (opt_x, true_x))
        self.assertLess(abs(opt_y - true_y), tolerance,
                      "The returned y = %f is not close to y = %f"
                      % (opt_y, true_y))
        self.assertLess(abs(opt_sin_th - np.sin(true_th)), tolerance,
                      "The returned sin_th = %f is not close to sin(%f) = %f"
                      % (opt_sin_th, true_th, np.sin(true_th)))
        self.assertLess(abs(opt_cos_th - np.cos(true_th)), tolerance,
                      "The returned cos_th = %f is not close to cos(%f) = %f"
                      % (opt_cos_th, true_th, np.cos(true_th)))

    @weight(5)
    @timeout_decorator.timeout(20.0)
    def test_03_perfect_drill_alignment(self):
        '''the perfect drill aligns with the model'''
        from realsense_point_cloud_registration import (align_scene_to_model,
                                                        transform_to_pose)

        model = np.load('./point_clouds/models/drill_model.npy')
        scene = np.load('./point_clouds/scenes/drill_model_transformed.npy')

        X_MS, error = align_scene_to_model(scene, model)

        true_th = np.pi/3
        true_x = -0.2
        true_y = 0.5

        tolerance = 1e-2

        opt_x, opt_y, opt_sin_th, opt_cos_th = transform_to_pose(X_MS)

        self.assertLess(abs(opt_x - true_x), tolerance,
                      "The returned x = %f is not close to x = %f"
                      % (opt_x, true_x))
        self.assertLess(abs(opt_y - true_y), tolerance,
                      "The returned y = %f is not close to y = %f"
                      % (opt_y, true_y))
        self.assertLess(abs(opt_sin_th - np.sin(true_th)), tolerance,
                      "The returned sin_th = %f is not close to sin(%f) = %f"
                      % (opt_sin_th, true_th, np.sin(true_th)))
        self.assertLess(abs(opt_cos_th - np.cos(true_th)), tolerance,
                      "The returned cos_th = %f is not close to cos(%f) = %f"
                      % (opt_cos_th, true_th, np.cos(true_th)))


    @weight(10)
    @timeout_decorator.timeout(30.0)
    def test_04_segmented_spatula_alignment(self):
        '''your segmented spatula aligns with the model'''
        from realsense_point_cloud_registration import (segment_spatula,
                                                        align_scene_to_model,
                                                        transform_to_pose)

        model = np.load('./point_clouds/models/spatula_model.npy')
        spatula_scene_points = np.load('./point_clouds/scenes/spatula_points.npy')
        spatula_scene_colors = np.load('./point_clouds/scenes/spatula_colors.npy')

        segmented_spatula_points, _ = \
            segment_spatula(spatula_scene_points, spatula_scene_colors)

        scene = segmented_spatula_points

        X_MS, error = align_scene_to_model(scene, model)

        homogenous_scene = np.ones((4, scene.shape[0]))
        homogenous_scene[:3, :] = scene.T

        transformed_scene = np.dot(X_MS, homogenous_scene).T[:, :3]

        opt_x, opt_y, opt_sin_th, opt_cos_th = transform_to_pose(X_MS)

        centroid_tolerance = 0.05 # 5 cm

        self.assertLess(
        np.linalg.norm(
            np.mean(transformed_scene, axis=0) - np.mean(model, axis=0)),
            centroid_tolerance,
            "The transformed point cloud is too far away from the model")

        th_s = np.arcsin(np.clip(opt_sin_th, -1.0, 1.0))
        th_c = np.arccos(np.clip(opt_cos_th, -1.0, 1.0))

        angle_tolerance = 1e-2

        quadrant_1 = abs(th_s - th_c) <= angle_tolerance
        quadrant_2 = abs((np.pi - th_s) - th_c) <= angle_tolerance
        quadrant_3 = abs((th_s + np.pi) - th_c) <= angle_tolerance
        quadrant_4 = abs((-th_s) - th_c) <= angle_tolerance

        self.assertTrue(quadrant_1 or quadrant_2 or quadrant_3 or quadrant_4,
                        "sin_th and cos_th aren't from the same angle")


    @weight(10)
    @timeout_decorator.timeout(30.0)
    def test_04_segmented_drill_alignment(self):
        '''your segmented drill aligns with the model'''
        from realsense_point_cloud_registration import (segment_drill,
                                                      align_scene_to_model,
                                                      transform_to_pose)

        model = np.load('./point_clouds/models/drill_model.npy')
        drill_scene_points = np.load('./point_clouds/scenes/drill_points.npy')
        drill_scene_colors = np.load('./point_clouds/scenes/drill_colors.npy')

        segmented_drill_points, _ = \
            segment_drill(drill_scene_points, drill_scene_colors)

        scene = segmented_drill_points

        X_MS, error = align_scene_to_model(scene, model)

        homogenous_scene = np.ones((4, scene.shape[0]))
        homogenous_scene[:3, :] = scene.T

        transformed_scene = np.dot(X_MS, homogenous_scene).T[:, :3]

        opt_x, opt_y, opt_sin_th, opt_cos_th = transform_to_pose(X_MS)

        centroid_tolerance = 0.05 # 5 cm

        self.assertLess(
        np.linalg.norm(
            np.mean(transformed_scene, axis=0) - np.mean(model, axis=0)),
            centroid_tolerance,
            "The transformed point cloud is too far away from the model")

        th_s = np.arcsin(np.clip(opt_sin_th, -1.0, 1.0))
        th_c = np.arccos(np.clip(opt_cos_th, -1.0, 1.0))

        angle_tolerance = 5e-3

        quadrant_1 = abs(th_s - th_c) <= angle_tolerance
        quadrant_2 = abs((np.pi - th_s) - th_c) <= angle_tolerance
        quadrant_3 = abs((th_s + np.pi) - th_c) <= angle_tolerance
        quadrant_4 = abs((-th_s) - th_c) <= angle_tolerance

        self.assertTrue(quadrant_1 or quadrant_2 or quadrant_3 or quadrant_4,
                        "sin_th and cos_th aren't from the same angle")


class TestPset3_PutObjectInCupboardTest(unittest.TestCase):
    @weight(10)
    @timeout_decorator.timeout(150.0)
    def test_00_pick_and_place(self):
        '''putting_object_in_cupboard_satisfies_all_requirements'''
        from kuka_simulator import KukaSimulator
        from kuka_open_cupboard_demo import GenerateIiwaPlansAndGripperSetPoints

        # Run simulation
        kuka_simulator = KukaSimulator()
        plan_list, gripper_setpoint_list = \
            GenerateIiwaPlansAndGripperSetPoints(kuka_simulator, is_printing=False)
        state_log = \
            kuka_simulator.RunSimulation(plan_list, gripper_setpoint_list,
                                         extra_time=5.0, is_test=True,
                                         real_time_rate=0.0)

        # Create context for final state
        x_final = state_log.data()[:, -1].flatten()
        # x_final = np.load("x_start.npy")
        plant = kuka_simulator.plant
        context = plant.CreateDefaultContext()
        tree = plant.tree()
        x_mutalbe = tree.get_mutable_multibody_state_vector(context)
        x_mutalbe[:] = x_final
        world_frame = plant.world_frame()

        # velocity of everything should be close to zero
        v = x_final[plant.num_positions():]
        v_max = np.abs(v).max()
        self.assertTrue(v_max < 0.02,
                        "Velocity of some bodies is not close to zero. "
                        "Maximum velocity is %f."%v_max)

        # cupboard must be closed
        hinge_joint = plant.GetJointByName("door_hinge")
        joint_angle = hinge_joint.get_angle(context)
        self.assertTrue(np.abs(joint_angle) < 0.02,
                        "Cupboard door is not fully closed.")

        # Origin of bottle frame must be inside the cupboard.
        X_WBox = tree.CalcRelativeTransform(
            context, frame_A=world_frame, frame_B=plant.GetFrameByName("base_link_box"))
        p_WBottle_final = X_WBox.translation()

        x_box = p_WBottle_final[0]
        y_box = p_WBottle_final[1]
        z_box = p_WBottle_final[2]

        # position of center of the bottom of cupboard in world frame
        p_center = kuka_simulator.X_WC.translation() + [0, -0.025 - 0.115, 0]

        x_center = p_center[0]
        y_center = p_center[1]
        table_top_z_in_world = kuka_simulator.table_top_z_in_world

        z_lb = table_top_z_in_world + 0.02
        z_ub = table_top_z_in_world + 0.02 + 0.21
        self.assertTrue(np.abs(x_box - x_center) < 0.125,
                        "Origin of the box body frame is not inside the cupboard. "
                        "x_box=%f is not inside [%f, %f]" % (x_box, x_center-0.125, x_center+0.125))
        self.assertTrue(np.abs(y_box - y_center) < 0.115,
                        "Origin of the box body frame is not inside the cupboard. "
                        "y_box=%f is not inside [%f, %f]" % (x_box, y_center-0.115, y_center+0.115))
        self.assertTrue(z_box > z_lb and z_box <= z_ub,
                        "Origin of the box body frame is not inside the cupboard. "
                        "z_box=%f is not inside [%f, %f]"%(z_box, z_lb, z_ub))


def pretty_format_json_results(test_output_file):
    import json
    import textwrap

    output_str = ""

    try:
        with open(test_output_file, "r") as f:
            results = json.loads(f.read())
 
        total_score_possible = 0.0

        if "tests" in results.keys():
            for test in results["tests"]:
                output_str += "Test %s: " % (test["name"])
                output_str += "%2.2f/%2.2f.\n" % (test["score"], test["max_score"])
                total_score_possible += test["max_score"]
                if "output" in test.keys():
                    output_str += "  * %s\n" % (
                        textwrap.fill(test["output"], 70,
                                      subsequent_indent = "  * "))
                output_str += "\n"

            output_str += "TOTAL SCORE (automated tests only): %2.2f/%2.2f\n" % (results["score"], total_score_possible)

        else:
            output_str += "TOTAL SCORE (automated tests only): %2.2f\n" % (results["score"])
            if "output" in results.keys():
                output_str += "  * %s\n" % (
                        textwrap.fill(results["output"], 70,
                                      subsequent_indent = "  * "))
                output_str += "\n"
    
    except IOError:
        output_str += "No such file %s" % test_output_file
    except Exception as e:
        output_str += "Other exception while printing results file: ", e

    return output_str

def global_fail_with_error_message(msg, test_output_file):
    import json

    results = {"score": 0.0,
               "output": msg}

    with open(test_output_file, 'w') as f:
        f.write(json.dumps(results,
                           indent=4,
                           sort_keys=True,
                           separators=(',', ': '),
                           ensure_ascii=True))

def run_tests(test_output_file = "test_results.json"):
    try:
        # Check for existence of the expected files
        expected_files = [
        ]
        for file in expected_files:
            if not os.path.isfile(file):
                raise ValueError("Couldn't find an expected file: %s" % file)

        do_testing = True

    except Exception as e:
        import traceback
        global_fail_with_error_message("Somehow failed trying to import the files needed for testing " +
                                       traceback.format_exc(1), test_output_file)
        do_testing = False

    if do_testing:
        test_cases = [TestPset3_PointCloudRegistrationTest,
                      TestPset3_PutObjectInCupboardTest]

        suite = unittest.TestSuite()
        for test_class in test_cases:
            tests = unittest.defaultTestLoader.loadTestsFromTestCase(test_class)
            suite.addTests(tests)

        with open(test_output_file, "w") as f:
            JSONTestRunner(stream=f).run(suite)

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print "Please invoke with one argument: the result json to write."
        print "(This test file assumes it's in the same directory as the code to be tested."
        exit(1)

    run_tests(test_output_file=sys.argv[1])

