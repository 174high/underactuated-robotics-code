import numpy as np
import meshcat.geometry as g
import meshcat.transformations as tf
from scipy.optimize import fmin_bfgs
from sklearn.neighbors import NearestNeighbors


def make_meshcat_color_array(N, r, g, b):
    '''Construct a color array to visualize a point cloud in meshcat.

    Args:
        N: int. number of points to generate. Must be >= number of points in the
            point cloud to color
        r: float. The red value of the points, 0.0 <= r <= 1.0
        g: float. The green value of the points, 0.0 <= g <= 1.0
        b: float. The blue value of the points, 0.0 <= b <= 1.0

    Returns:
        Nx3 numpy array of the same color
    '''
    color = np.zeros((3, N))
    color[0, :] = r
    color[1, :] = g
    color[2, :] = b

    return color.T
  

def plot_meshcat_point_cloud(meshcat_vis, point_cloud_name, points, colors):
    '''A wrapper function to plot meshcat point clouds.

    Args:
        meshcat_vis: an instance of a meshcat visualizer
        point_cloud_name: string. The name of the meshcat point clouds
        points: Nx3 numpy array of (x, y, z) points
        colors: Nx3 numpy array of (r, g, b) colors corresponding to points
    '''

    meshcat_vis[point_cloud_name].set_object(g.PointCloud(points.T, colors.T))

def visualize_transform(meshcat_vis, points, transform):
    '''
    Visualize the points transformed by transform. Plots the transformed points
    in yellow.

    Args:
        meschat_vis: an instance of a meshcat visualizer
        points: an Nx3 numpy array representing a point cloud
        transform: 4x4 numpy array representing a homogeneous transformation 
    '''

    # Make meshcat color arrays.
    N = points.shape[0]

    yellow = make_meshcat_color_array(N, 1, 1, 0)

    homogenous_points = np.ones((N, 4))
    homogenous_points[:, :3] = np.copy(points)

    transformed_points = transform.dot(homogenous_points.T)

    transformed_points_meshcat = \
        g.PointCloud(transformed_points[:3, :], yellow.T)

    meshcat_vis['transformed_observations'].set_object(
        transformed_points_meshcat)


def threshold_array(arr, min_val, max_val):
    '''Finds where the values of arr are between min_val and max_val
       (inclusive).

    Args:
        arr: (N, ) numpy array containing number values
        min_val: number. the minimum value threshold
        max_val: number. the maximum value threshold

    Returns:
        An (M, ) numpy array of the integer indices in arr with values that
        are between min_val and max_val
    '''
    return np.where(
        abs(arr - (max_val + min_val) / 2.) < (max_val - min_val) / 2.)[0]


def isolate_table(scene_points, scene_colors):
    '''Removes all points that aren't a part of the robot table set up.

    Args:
        scene_points: Nx3 numpy array representing a scene
        scene_colors: Nx3 numpy array of rgb values corresponding to the points
            in scene_points

    Returns:
        table_points: Mx3 numpy array of points in the table area
        table_colors: Mx3 numpy array of the colors of the table points
    '''
    x_min = -0.85
    x_max = 1

    y_min = -0.5
    y_max = 0.5

    z_min = 0.0
    z_max = 0.5

    x_indices = threshold_array(scene_points[:, 0], x_min, x_max)
    y_indices = threshold_array(scene_points[:, 1], y_min, y_max)
    z_indices = threshold_array(scene_points[:, 2], z_min, z_max)

    indices = reduce(np.intersect1d, (x_indices, y_indices, z_indices))

    table_points = scene_points[indices, :]
    table_colors = scene_colors[indices, :]

    return table_points, table_colors


def segment_spatula(scene_points, scene_colors):
    '''Removes all points that aren't a part of the spatula.

    Args:
        scene_points: Nx3 numpy array representing a scene
        scene_colors: Nx3 numpy array of rgb values corresponding to the points
            in scene_points

    Returns:
        spatula_points: Mx3 numpy array of points on the spatula
        spatula_colors: Mx3 numpy array of the colors of the spatula
    '''
    
    spatula_points = np.copy(scene_points)
    spatula_colors = np.copy(scene_colors)

    # your code here
    ####################

    ####################

    return spatula_points, spatula_colors


def segment_drill(scene_points, scene_colors):
    '''Removes all points that aren't a part of the spatula.

    Args:
        scene_points: Nx3 numpy array representing a scene
        scene_colors: Nx3 numpy array of rgb values corresponding to the points
            in scene_points

    Returns:
        drill_points: Mx3 numpy array of points on the drill
        drill_colors: Mx3 numpy array of the colors of the drill
    '''
    
    drill_points = np.copy(scene_points)
    drill_colors = np.copy(scene_colors)

    # your code here
    ####################

    ####################

    return drill_points, drill_colors


def pose_to_transform(pose):
    '''Puts an (x, y, sin(theta), cos(theta)) pose into a 4x4 homogenous
       transformation matrix with a translation by x and y and rotation by theta
       about the z-axis.

    Args:
        pose: (4,) numpy matrix containing an (x, y, sin(theta), cos(theta))
            transform

    Returns:
        transform: 4x4 numpy matrix representing the homogenous transformation
            from pose

            transform = [cos(theta), -sin(theta),   0,    x]
                        [sin(theta),  cos(theta),   0,    y]
                        [0,           0,            1,    0]
                        [0,           0,            0,    1])
    '''
    transform = np.eye(4)
    x, y, sin_th, cos_th = pose

    transform[0, 3] = x
    transform[1, 3] = y
    transform[0, 0] = cos_th
    transform[1, 1] = cos_th
    transform[1, 0] = sin_th
    transform[0, 1] = -sin_th

    return transform


def transform_to_pose(transform):
    '''Takes the pose parameters from a 4x4 homogenous transformation matrix
       with a translation by x and y and rotation ab rotation by theta about the
       z-axis.

    Args:
        transform: 4x4 numpy matrix representing a homogenous transformation

            transform = [cos(theta), -sin(theta),   0,    x]
                        [sin(theta),  cos(theta),   0,    y]
                        [0,           0,            1,    0]
                        [0,           0,            0,    1])

    Returns:
        a (4,) numpy array with the pose information in the order
        (x, y, sin(theta), cos(theta))
    '''
    return np.array([transform[0, 3],
                     transform[1, 3],
                     transform[1, 0],
                     transform[0, 0]])


def best_fit_transform(scene_points, model_points, init_guess, max_distance):
    '''Find the best fit (x, y, sin(theta), cos(theta)) values that map
       scene_points to model_points given an initial guess.

    Args:
        scene_points: Nx4 numpy array of homogenous points in the scene
        model_points: Nx4 numpy array of homogenous points in the model
        init_guess: (4,) numpy array of an (x, y, sin(theta), cos(theta)) guess
        max_distance: float. the maximum distance in meters to consider of
            nearest neighbors between scene_points and model_points

    Returns:
        X_MS: 4x4 numpy array of the best-fit homogenous transformation between
            scene_points and model_points
        cost: float. the cost function evaluated at X_MS
    '''
    X_MS = np.eye(4)
    nn = NearestNeighbors(
            n_neighbors=1, algorithm='kd_tree').fit(model_points.T[:, :3])
    
    def cost(pose_vector):
        '''The objective to minimize.

        Args:
            pose_vector: (4,) numpy array of an (x, y, sin_th, cos_th) pose

        Returns:
            cost: float. the value of the objective at pose_vector
        '''
        x, y, sin_th, cos_th = pose_vector
        X_MS = pose_to_transform(pose_vector)

        cost = 0

        # your code here
        ####################

        ####################

        return cost
    
    init_pose = transform_to_pose(init_guess)
    init_cost = cost(init_pose)

    ans = fmin_bfgs(cost, init_pose, disp=0, full_output=True)
    pose, cost = ans[0:2]

    X_MS = pose_to_transform(pose)
    return X_MS, cost


def align_scene_to_model(scene_points, model_points,
                         max_distance=0.05, num_iters=10,
                         num_sample_points=250):
    '''Find a good (x, y, sin(theta), cos(theta) transform between scene_points
       and model_points.

    Args:
        scene_points: Nx3 numpy array of scene points
        model_points: Nx3 numpy array of model points
        max_distance: float. the maximum distance in meters to consider of
            nearest neighbors between scene_points and model_points
        num_iters: int. the number of times to try the best fit optimization
            from different initial guesses.
        num_sample_points: int. the number of points to sample from the scene to
            limit the time the algorithm takes to run

    Returns:
        best_X_MS: the best 4x4 homogenous transform between scene_points and
            model_points
        best_cost: float. the cost function evaluated at bestX_MS
    '''
    scene_sample = scene_points[np.random.choice(scene_points.shape[0],
                                                 num_sample_points,
                                                 replace=False),
                                :]

    homogenous_scene = np.ones((4, scene_sample.shape[0]))
    homogenous_model = np.ones((4, model_points.shape[0]))

    homogenous_scene[:3, :] = scene_sample.T
    homogenous_model[:3, :] = model_points.T

    centroid_scene = np.mean(homogenous_scene, axis=1)
    centroid_model = np.mean(homogenous_model, axis=1)

    best_X_MS = None
    best_cost = float('inf')

    for i in range(num_iters):
        init_theta = np.random.uniform(0, 2*np.pi)
        
        init_guess = reduce(np.dot,
                           [tf.translation_matrix((centroid_model[0],
                                                   centroid_model[1],
                                                   0.)),
                            tf.rotation_matrix(init_theta, (0, 0, 1)),
                            tf.translation_matrix((-centroid_scene[0],
                                                   -centroid_scene[1],
                                                   0.))])
        
        X_MS, cost = best_fit_transform(
            homogenous_scene,homogenous_model, init_guess, max_distance)
        
        if cost < best_cost:
            best_cost = cost
            best_X_MS = X_MS

    return best_X_MS, best_cost