import os
import imp
import sys
import timeout_decorator
import unittest
import math
import numpy as np
import random
from gradescope_utils.autograder_utils.decorators import weight
from gradescope_utils.autograder_utils.json_test_runner import JSONTestRunner
from pydrake.forwarddiff import gradient

def HessianNonConvexF(x):
    ddf = np.zeros((2, 2))
    ddf[0, 0] = -np.sin(x[0]) * np.sin(x[1])
    ddf[0, 1] = np.cos(x[0]) * np.cos(x[1])
    ddf[1, 0] = np.cos(x[0]) * np.cos(x[1])
    ddf[1, 1] = -np.sin(x[0]) * np.sin(x[1])

    return ddf

def BlockPrint():
    sys.stdout = open(os.devnull, 'w')

def EnablePrint():
    sys.stdout = sys.__stdout__

class TestPset1b_GradientDescentTest(unittest.TestCase):
    @weight(6)
    @timeout_decorator.timeout(1.0)
    def test_00_gradient_descent_converges_to_global_minimum(self):
        '''gradient_descent_converges_to_global_minimum'''

        from optimization import GradientDescent

        minima = np.array([[10.,10.], [-2.,-5.]])
        initial_guesses = np.array([[100., 100.], [50., 50.]])
        for i, minimum in enumerate(minima):
            def F(x):
                result = ((x-minimum)**2).sum()
                return np.array([result])

            def dF(x):
                df = np.zeros(2)
                df[0] = 2*(x[0] - minimum[0])
                df[1] = 2*(x[1] - minimum[1])
                return df

            x_star, f_star = GradientDescent(F, dF, initial_guesses[i])
            self.assertTrue(np.allclose(x_star, minimum),
                            "f(x,y) = (x-%f)^2*(y-%f)^2 does not converge to "
                            "its global minimum. Your algorithm terminates at"
                            "[%f, %f]." % (minimum[0], minimum[1], x_star[0], x_star[1]))

            self.assertTrue(np.isclose([f_star], [0]),
                            "Minimum value of f(x,y) = (x-%f)^2*(y-%f)^2 should"
                            "be close to 0. Your optimum value is %f" \
                            %(minimum[0], minimum[1], f_star))

    @weight(2)
    @timeout_decorator.timeout(1.0)
    def test_01_local_minimum(self):
        '''gradient_descent_converges_to_local_minimum'''

        from optimization import (GradientDescent,
                                  initial_guess_minimum,
                                  GradientNonconvexF,
                                  NonConvexF)

        x_star, f_star = GradientDescent(NonConvexF, GradientNonconvexF, initial_guess_minimum)

        df = gradient(NonConvexF, x_star)
        self.assertTrue(np.linalg.norm(df)<1e-3,
                        "Gradient does not vanish at the optimal point returned by your "
                        "GradientDescent implementation. Gradient is [%f, %f], your optimal"
                         " point is [%f, %f]"%(df[0], df[1], x_star[0], x_star[1]))
        self.assertFalse(np.allclose(x_star, np.array([np.pi/2, -np.pi/2])),
                         "Your local minimum initial guess should converge to a local minimum that is "
                         "different from [pi/2, -pi/2].")

        self.assertTrue(np.linalg.det(HessianNonConvexF(x_star)) > 0,
                        "Your initial guess converges to a saddle point.")

    @weight(2)
    @timeout_decorator.timeout(1.0)
    def test_02_saddle(self):
        '''gradient_descent_converges_to_a_saddle'''

        from optimization import (GradientDescent,
                                  initial_guess_saddle,
                                  GradientNonconvexF,
                                  NonConvexF)

        x_star, f_star = GradientDescent(NonConvexF, GradientNonconvexF, initial_guess_saddle)

        df = gradient(NonConvexF, x_star)
        self.assertTrue(np.linalg.norm(df)<1e-3,
                        "Gradient does not vanish at the optimal point returned by your "
                        "GradientDescent implementation. Gradient is [%f, %f], your optimal"
                         " point is [%f, %f]"%(df[0], df[1], x_star[0], x_star[1]))

        self.assertTrue(np.linalg.det(HessianNonConvexF(x_star)) < 0,
                        "Your initial guess converges to a local minimum.")


class TestPset1b_PlanarArmIkTest(unittest.TestCase):
    @weight(2)
    @timeout_decorator.timeout(20.0)
    def test_00_two_link_trig_ik(self):
        '''two_link_trig_ik_works'''
        from inverse_kin_planar_arm import InverseKinByTrigonometry, ForwardKinematics

        desired_ee_states_list = [np.array([2.0, 0.0]),
                          np.array([0.0, 1.0]),
                          np.array([0.0, -1.0]),
                          np.array([1.0, 1.0]),
                          np.array([-1.0, -1.0]),
                          np.array([-1.0, 1.0]),
                          np.array([1.0, -1.0]),
                         ]

        for desired_ee_state in desired_ee_states_list:
            joint_angles = InverseKinByTrigonometry(desired_ee_state)
            actual_ee_state = ForwardKinematics(joint_angles).astype(np.float64).round(2)

            self.assertTrue(
                np.allclose(actual_ee_state, desired_ee_state),
                "".join([
                    "actual_ee_state = ",
                    np.array_str(actual_ee_state),
                    " was not close to the desired end effector state = ",
                    np.array_str(desired_ee_state)
                    ])
            )
        
    @weight(3)
    @timeout_decorator.timeout(20.0)
    def test_01_two_link_grad_descent_ik(self):
        '''two_link_grad_descent_ik_works'''
        from inverse_kin_planar_arm import InverseKinByGradientDescent, ForwardKinematics

        desired_ee_states_list = [np.array([2.0, 0.0]),
                                  np.array([0.0, 1.0]),
                                  np.array([0.0, -1.0]),
                                  np.array([1.0, 1.0]),
                                  np.array([-1.0, -1.0]),
                                  np.array([-1.0, 1.0]),
                                  np.array([1.0, -1.0]),
                                 ]

        init_guesses_list = [np.array([1e-3, 1e-3]),
                             np.array([3, 0]),
                             np.array([0.1, 1.5]),
                             np.array([1.57, 0]),
                             np.array([-1.57, 0]),
                             np.array([0.4, 0.6]),
                             np.array([0.3, 1.57]),
                            ]

        for i, desired_ee_state in enumerate(desired_ee_states_list):
            theta0 = init_guesses_list[i]

            joint_angles = InverseKinByGradientDescent(desired_ee_state, theta0)[0]

            actual_ee_state = ForwardKinematics(joint_angles).astype(np.float64).round(2)

            self.assertTrue(
                np.allclose(actual_ee_state, desired_ee_state),
                "".join([
                    "actual_ee_state = ",
                    np.array_str(actual_ee_state),
                    " was not close to the desired end effector state = ",
                    np.array_str(desired_ee_state)
                    ])
            )

    @weight(2)
    @timeout_decorator.timeout(20.0)
    def test_02_two_link_grad_descent_local_min(self):
        '''two_link_grad_descent_different_local_minima'''
        from inverse_kin_planar_arm import InverseKinLocalMinimum, ForwardKinematics

        solutions = InverseKinLocalMinimum(np.array([0.3, 0.6]))

        self.assertTrue(len(np.unique(solutions)) == 4, 
                    "".join([
                    "first joint angles ",
                    np.array_str(solutions[0]),
                    " were not different from the second joint angles ",
                    np.array_str(solutions[1])
                    ]))

        ee_states_0 = ForwardKinematics(solutions[0]).astype(np.float64)
        ee_states_1 = ForwardKinematics(solutions[1]).astype(np.float64)

        self.assertTrue(np.allclose(ee_states_0, ee_states_1), 
            "".join([
            "end effector positions ",
            np.array_str(ee_states_0),
            "and ",
            np.array_str(ee_states_1),
            "are not the same"
            ]))

    @weight(3)
    @timeout_decorator.timeout(20.0)
    def test_03_three_link_grad_descent_ik(self):
        '''three_link_grad_descent_ik_works'''
        from inverse_kin_planar_arm import InverseKinByGradientDescentThreeLink, ForwardKinematicsThreeLink

        desired_ee_states_list = [np.array([2.5, 0.0, 0.0]),
                                  np.array([0.0, 1.0, 0.0]),
                                  np.array([0.0, -1.0, 0.0]),
                                  np.array([1.0, 1.0, 0.0]),
                                  np.array([-1.0, -1.0, 0.0]),
                                  np.array([-1.0, 1.0, 0.0]),
                                  np.array([1.0, -1.0, 0.0]),
                                 ]

        init_guesses_list = [np.array([1e-3, 1e-3, 1e-3]),
                             np.array([3.0, 0.0, 2.0]),
                             np.array([-3.0, 2.0, 1.0]),
                             np.array([2.0, -2.0, 0.0]),
                             np.array([-3.0, 1.0, 2.0]),
                             np.array([2.0, 1.0, -3.0]),
                             np.array([-2.0, 2.0, 0.0]),
                            ]

        for i, desired_ee_state in enumerate(desired_ee_states_list):
            theta0 = init_guesses_list[i]

            joint_angles = InverseKinByGradientDescentThreeLink(desired_ee_state, theta0)[0]

            actual_ee_state = ForwardKinematicsThreeLink(joint_angles).astype(np.float64).round(2)

            self.assertTrue(
                np.allclose(actual_ee_state[:2], desired_ee_state[:2]),
                "".join([
                    "actual_ee_state = ",
                    np.array_str(actual_ee_state[:2]),
                    " was not close to the desired end effector state = ",
                    np.array_str(desired_ee_state[:2])
                    ])
            )

    @weight(3)
    @timeout_decorator.timeout(20.0)
    def test_04_three_link_mp_ik(self):
        '''three_link_mp_ik_works'''
        from inverse_kin_planar_arm import IkThreeLinkArmMathematicalProgram, ForwardKinematicsThreeLink

        desired_ee_states_list = [np.array([2.5, 0.0]),
                                  np.array([0.0, 1.0]),
                                  np.array([0.0, -1.0]),
                                  np.array([1.0, 1.0]),
                                  np.array([-1.0, -1.0]),
                                  np.array([-1.0, 1.0]),
                                  np.array([1.0, -1.0]),
                                 ]

        theta_ee_desired_list = [0.0,
                                 np.pi/2,
                                 -np.pi,
                                 np.sqrt(2)/2,
                                 np.sqrt(2)/2,
                                 np.sqrt(2)/2,
                                 np.sqrt(2)/2,
                                ]

        init_guesses_list = [np.array([1e-3, 1e-3, 1e-3]),
                             np.array([3.0, 0.0, 2.0]),
                             np.array([-3.0, 2.0, 1.0]),
                             np.array([2.0, -2.0, 0.0]),
                             np.array([-3.0, 1.0, 2.0]),
                             np.array([2.0, 1.0, -3.0]),
                             np.array([-2.0, 2.0, 0.0]),
                            ]

        for i, desired_ee_state in enumerate(desired_ee_states_list):
            theta0 = init_guesses_list[i]
            theta_ee_desired = theta_ee_desired_list[i]

            joint_angles = IkThreeLinkArmMathematicalProgram(desired_ee_state, theta_ee_desired, theta0)[0]

            actual_ee_state = ForwardKinematicsThreeLink(joint_angles).astype(np.float64).round(2)

            self.assertTrue(
                np.allclose(actual_ee_state[:2], desired_ee_state[:2]),
                "".join([
                    "actual_ee_state = ",
                    np.array_str(actual_ee_state[:2]),
                    " was not close to the desired end effector state = ",
                    np.array_str(desired_ee_state[:2])
                    ])
            )

    @weight(3)
    @timeout_decorator.timeout(20.0)
    def test_05_three_link_drake_ik(self):
        '''three_link_using_drakes_ik_interface'''
        from inverse_kin_planar_arm import (IkThreeLinkArmByDrakeInverseKinematics,
                                            ForwardKinematicsPointMbp)

        theta_solution, result, mbp_3_link = IkThreeLinkArmByDrakeInverseKinematics()
        self.assertTrue(np.abs(theta_solution[0] - np.pi/6) <= 0.01,
                        "Error between the first joint angle in your solution (%f)"
                        " and pi/6 is greater than 0.01"%theta_solution[0])


        p_EQ = np.array([0.0, 0.1, 0.1])
        p_WQ_desired = np.array([0, 1.2, 1.5])
        frame = mbp_3_link.GetBodyByName("link_ee").body_frame()
        p_WQ = ForwardKinematicsPointMbp(p_EQ, theta_solution, frame, mbp_3_link)
        self.assertTrue(np.linalg.norm(p_WQ - p_WQ_desired) <= 0.02,
                        "Actual position of Q in world frame is [%f %f %f], which is too far"
                        " away from the desired position [0, 1.2, 1.5]"%(p_WQ[0], p_WQ[1], p_WQ[2]))


def pretty_format_json_results(test_output_file):
    import json
    import textwrap

    output_str = ""

    try:
        with open(test_output_file, "r") as f:
            results = json.loads(f.read())
 
        total_score_possible = 0.0

        if "tests" in results.keys():
            for test in results["tests"]:
                output_str += "Test %s: " % (test["name"])
                output_str += "%2.2f/%2.2f.\n" % (test["score"], test["max_score"])
                total_score_possible += test["max_score"]
                if "output" in test.keys():
                    output_str += "  * %s\n" % (
                        textwrap.fill(test["output"], 70,
                                      subsequent_indent = "  * "))
                output_str += "\n"

            output_str += "TOTAL SCORE (automated tests only): %2.2f/%2.2f\n" % (results["score"], total_score_possible)

        else:
            output_str += "TOTAL SCORE (automated tests only): %2.2f\n" % (results["score"])
            if "output" in results.keys():
                output_str += "  * %s\n" % (
                        textwrap.fill(results["output"], 70,
                                      subsequent_indent = "  * "))
                output_str += "\n"
    
    except IOError:
        output_str += "No such file %s" % test_output_file
    except Exception as e:
        output_str += "Other exception while printing results file: ", e

    return output_str

def global_fail_with_error_message(msg, test_output_file):
    import json

    results = {"score": 0.0,
               "output": msg}

    with open(test_output_file, 'w') as f:
        f.write(json.dumps(results,
                           indent=4,
                           sort_keys=True,
                           separators=(',', ': '),
                           ensure_ascii=True))

def run_tests(test_output_file = "test_results.json"):
    try:
        # Check for existence of the expected files
        expected_files = [
        ]
        for file in expected_files:
            if not os.path.isfile(file):
                raise ValueError("Couldn't find an expected file: %s" % file)

        do_testing = True

    except Exception as e:
        import traceback
        global_fail_with_error_message("Somehow failed trying to import the files needed for testing " + traceback.format_exc(1), test_output_file)
        do_testing = False

    if do_testing:
        test_cases = [TestPset1b_GradientDescentTest, TestPset1b_PlanarArmIkTest]

        suite = unittest.TestSuite()
        for test_class in test_cases:
            tests = unittest.defaultTestLoader.loadTestsFromTestCase(test_class)
            suite.addTests(tests)

        with open(test_output_file, "w") as f:
            JSONTestRunner(stream=f).run(suite)

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print "Please invoke with one argument: the result json to write."
        print "(This test file assumes it's in the same directory as the code to be tested."
        exit(1)

    run_tests(test_output_file=sys.argv[1])

