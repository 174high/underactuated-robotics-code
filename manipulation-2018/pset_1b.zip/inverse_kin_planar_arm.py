import os
import numpy as np
from pydrake.forwarddiff import gradient
from pydrake.all import MathematicalProgram
import pydrake.symbolic as sym
from optimization import GradientDescent

from pydrake.multibody.multibody_tree.multibody_plant import MultibodyPlant
from pydrake.geometry import SceneGraph
from pydrake.multibody.multibody_tree.parsing import AddModelFromSdfFile
from pydrake.multibody.multibody_tree import UniformGravityFieldElement
from pydrake.multibody import inverse_kinematics as ik

l1 = 1.
l2 = 1.
l3 = 0.5

'''
theta: numpy array of joint angles, shape: (2,) 
return value: end effector position in world frame, shape: (2,)
'''
def ForwardKinematics(theta):
    x_ee = np.empty(2, dtype=object)
    x_ee[0] = l1*np.cos(theta[0]) + l2*np.cos(theta[0] + theta[1])
    x_ee[1] = l1*np.sin(theta[0]) + l2*np.sin(theta[0] + theta[1])
    return x_ee

'''
Solves inverse kinematics analytically. 
x_ee_target \in R^2 is the desired end effector position in the global x-y plane.
return value: numpy array of joint angles, shape: (2,) 
'''
def InverseKinByTrigonometry(x_ee_target):
    theta = np.zeros(2)
    ## your code here
    ###############################

    ###############################
    return theta


'''
x_ee_desired: numpy array of shape of (2,)
theta_initial_guess: numpy array of shape (2,)
'''
def InverseKinByGradientDescent(x_ee_desired, theta_initial_guess):
    # theta: numpy array of joint angles, shape: (2,)
    # return value: numpy array of objective function value, shape: (1,)
    def Objective(theta):
        objective_value = 0.
        ## your code here
        ###############################

        ###############################
        return np.array([objective_value])

    # theta: numpy array of joint angles, shape: (2,)
    # return value: numpy array of Objective's gradient at theta, shape: (2,)
    def GradientObjective(theta):
        df = np.zeros(2)
        ## your code here
        ###############################

        ###############################
        return df

    x_star, f_star = GradientDescent(Objective, GradientObjective, theta_initial_guess)
    return x_star, f_star, Objective


def InverseKinLocalMinimum(x_ee_desired):
    theta_0 = np.zeros(2)
    theta_1 = np.zeros(2)
    ## your code here
    ###############################

    ###############################

    initial_guesses = [theta_0, theta_1]
    solutions = np.zeros((2,2))

    for i in range(2):
        solutions[i], _, _ = InverseKinByGradientDescent(x_ee_desired, initial_guesses[i])

    return solutions

'''
theta: numpy array of joint angles, shape: (3,) 
return value: end effector position in world frame and the angle of the last link
'''
def ForwardKinematicsThreeLink(theta):
    x3_ee = np.empty(3, dtype=object)

    theta_0 = theta[0]
    theta_01 = theta_0 + theta[1]
    theta_012 = theta_01 + theta[2]

    x3_ee[0] = l1*np.cos(theta_0) + l2*np.cos(theta_01) + l3*np.cos(theta_012)
    x3_ee[1] = l1*np.sin(theta_0) + l2*np.sin(theta_01) + l3*np.sin(theta_012)
    x3_ee[2] = theta_012

    return x3_ee


'''
x_ee_desired: numpy array of shape of (3,)
theta_initial_guess: numpy array of shape (3,)
'''
def InverseKinByGradientDescentThreeLink(x3_ee_desired, theta_initial_guess):
    # theta: numpy array of joint angles, shape: (3,)
    # return value: numpy array of objective function value, shape: (1,)
    def ObjectiveThreeLink(theta):
        objective_value = 0.
        ## your code here
        ###############################

        ###############################
        return np.array([objective_value])


    # theta: numpy array of joint angles, shape: (3,)
    # return value: numpy array of Objective's gradient at theta, shape: (3,)
    def GradientObjectiveThreeLink(theta):
        df = np.zeros(3)
        ## your code here
        ###############################

        ###############################
        return df

    x_star, f_star = GradientDescent(ObjectiveThreeLink,
                                     GradientObjectiveThreeLink,
                                     theta_initial_guess)
    return x_star, f_star, ObjectiveThreeLink


'''
x_ee_desired: numpy array of shape (2,), desired end effector position.
theta_ee_desired: float64, desired end effector orientation.
theta_initial_guess: numpy array of shape (3,), initial guess for the decision variables. 
'''
def IkThreeLinkArmMathematicalProgram(x_ee_desired, theta_ee_desired,
                                      theta_initial_guess):
    theta_value = np.zeros(3)
    prog = MathematicalProgram()
    # result should be assigned by calling prog.Solve()
    result = None
    ## your code here
    ###############################

    ###############################
    return theta_value, result


two_link_arm_path = os.path.join(os.getcwd(), "models", "two_link_arm.sdf")

def ForwardKinematicsMbp(theta, frame, mbp):
    context = mbp.CreateDefaultContext()
    tree = mbp.tree()
    assert len(theta) == mbp.get_actuation_input_port().size(), \
        "len(theta) is not equal to the number of joints of the robot."

    for i, joint_angle in enumerate(theta):
        joint = mbp.GetJointByName("joint_%d"%(i+1))
        joint.set_angle(context=context, angle=joint_angle)

    world_frame = mbp.world_frame()

    X_WE = tree.CalcRelativeTransform(
        context, frame_A=world_frame, frame_B=frame)

    return X_WE.translation()

def ForwardKinematicsPointMbp(p_BQ, theta, frame, mbp):
    context = mbp.CreateDefaultContext()
    tree = mbp.tree()
    p_BQ = np.array(p_BQ)
    assert p_BQ.size == 3
    assert len(theta) == mbp.get_actuation_input_port().size(), \
        "len(theta) is not equal to the number of joints of the robot."

    for i, joint_angle in enumerate(theta):
        joint = mbp.GetJointByName("joint_%d"%(i+1))
        joint.set_angle(context=context, angle=joint_angle)

    world_frame = mbp.world_frame()

    p_WQ = tree.CalcPointsPositions(
        context, frame_B=frame, p_BQi=p_BQ.reshape(3,1), frame_A=world_frame).flatten()

    return p_WQ

def IkThreeLinkArmByDrakeInverseKinematics():
    three_link_arm_path = os.path.join(
        os.getcwd(), "models", "three_link_arm.sdf")
    # construct multibodyplant
    timestep = 0.0002
    mbp = MultibodyPlant(timestep)
    scene_graph = SceneGraph()

    # Add models
    arm_model = AddModelFromSdfFile(
        file_name=three_link_arm_path, model_name='robot',
        scene_graph=scene_graph, plant=mbp)


    # finalize multibodyplant
    mbp.Finalize(scene_graph)
    assert mbp.geometry_source_is_registered()

    # create an instance of InverseKinematics from a multibodyplant.
    ik_three_link_arm = ik.InverseKinematics(mbp)
    theta_solution = np.zeros(3)
    result = "Nothing here!"

    # we want point [0.1, 0.1] in frame EE to
    # match point [0.5, 0.5] in world frame.
    # your code here...
    ############################################################

    ############################################################

    return theta_solution, result, mbp





