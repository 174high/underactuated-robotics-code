import numpy as np

def QuadraticF(x):
    return np.array([x[0]**2 + x[1]**2])

'''
This function returns the gradient of QuadraticF.
The return value should be a numpy array with shape (2,).
'''
def GradientQuadraticF(x):
    df = np.array([0., 0.])
    ## your code here
    ###############################

    ###############################
    return df


def NonConvexF(x):
    return np.array([np.sin(x[0])*np.sin(x[1])])

'''
This function returns the gradient of NonConvexF.
The return value should be a numpy array with shape (2,).
'''
def GradientNonconvexF(x):
    df = np.zeros(2)
    ## your code here
    ###############################

    ###############################
    return df


'''
f(x): objective function. 
    x is a 1-dimensional numpy array.
    f(x) returns a numpy array of shape (1,), which is effectively 
    a scalar. 
f_gradient(x): gradient of objective function. 
    x is a 1-dimensional numpy array.
    f_gradient(x) returns the gradient of f at x. The returned 
    gradient is a numpy array of the same shape as x. 
x0: initial guess, a one-dimensional numpy array. 
'''
def GradientDescent(f, f_gradient, x0):
    x = np.array(x0)
    iteration_limit = 1000
    iteration_count = 0

    while iteration_count < iteration_limit:
        ## your code here
        ###############################

        ###############################
        iteration_count += 1

    if iteration_count == iteration_limit:
        print "Fail to converge within %d iterations."%iteration_limit

    return x, f(x)


initial_guess_saddle = \
    np.array([2., -2.]) # replace this with your answer.
initial_guess_minimum = \
    np.array([2., -2.]) # replace this with your answer.

