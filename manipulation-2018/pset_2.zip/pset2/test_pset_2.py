import os
import imp
import sys
import timeout_decorator
import unittest
import math
import numpy as np
import random
from gradescope_utils.autograder_utils.decorators import weight
from gradescope_utils.autograder_utils.json_test_runner import JSONTestRunner
from pydrake.util.eigen_geometry import Isometry3

# ground truth poses
from kuka_multibody_sim_w_control import X_WObject, X_WBox
p_WBoxO = X_WBox.translation()


class TestPset2_BasicICPTest(unittest.TestCase):
    @weight(2)
    @timeout_decorator.timeout(10.0)
    def test_00_nearest_neighbors(self):
        '''nearest_neightbors_works_for_small_number_of_points'''

        from iterative_closest_point import nearest_neighbors

        point_cloud_A = np.array([[0, 0, 0],
                                  [1, 2, 3],
                                  [10, 9, 8],
                                  [-3, -4, -5]])

        point_cloud_B = np.array([[10, 9, 8],
                                  [-3, -4, -5],
                                  [1, 2, 3],
                                  [0, 0, 0]])

        actual_distances, actual_indices = nearest_neighbors(point_cloud_A,
                                                             point_cloud_B)


        expected_distances = np.zeros(point_cloud_A.shape[0])
        expected_indices = np.array([3, 2, 0, 1])

        self.assertTrue(
                np.allclose(actual_distances, expected_distances),
                "".join([
                    "actual_distances = ",
                    np.array_str(actual_distances),
                    " was not close to the expected_distances = ",
                    np.array_str(expected_distances)
                    ])
            )

        self.assertTrue(
                np.allclose(actual_indices, expected_indices),
                "".join([
                    "actual_indices = ",
                    np.array_str(actual_indices),
                    " was not close to the expected_indices = ",
                    np.array_str(expected_indices)
                    ])
            )

    @weight(2)
    @timeout_decorator.timeout(1.0)
    def test_01_least_squares_transform(self):
        '''least_squares_transform_works_for_small_number_of_points'''

        from iterative_closest_point import least_squares_transform

        point_cloud_A = np.array([[0, 0, 0],
                                  [1, 2, 3],
                                  [10, 9, 8],
                                  [3, -4, -5]])

        point_cloud_Ah = np.ones((4, point_cloud_A.shape[0]))
        point_cloud_Ah[:3, :] = np.copy(point_cloud_A.T)

        R = np.array([[0.707, -0.707, 0],
                      [0.707, 0.7070, 0],
                      [0, 0, 1]])

        t = np.array([1, 2, 3])

        expected_X_BA = np.identity(4)
        expected_X_BA[:3, :3] = R
        expected_X_BA[:3, 3] = t

        point_cloud_B = np.dot(expected_X_BA, point_cloud_Ah)[:3, :]

        actual_X_BA = least_squares_transform(point_cloud_A, point_cloud_B.T)

        self.assertTrue(
                np.allclose(np.around(actual_X_BA, decimals=3), expected_X_BA),
                "".join([
                    "actual transform = ",
                    np.array_str(np.around(actual_X_BA, decimals=2)),
                    " was not close to the expected transform = ",
                    np.array_str(expected_X_BA)
                    ])
            )


    @weight(8)
    @timeout_decorator.timeout(60.0)
    def test_02_seeded_icp(self):
      '''ICP_converges_when_initial_guess_is_final_transform'''
      from iterative_closest_point import (nearest_neighbors,
                                           least_squares_transform,
                                           icp)

      spatula_model = np.load("resources/spatula_model.npy")
      spatula_scene = np.load("resources/spatula_scene.npy")

      sugar_box_model = np.load("resources/sugar_box_model.npy")
      sugar_box_scene = np.load("resources/sugar_box_scene.npy")

      apple_model = np.load("resources/apple_model.npy")
      apple_scene = np.load("resources/apple_scene.npy")

      expected_error_upper_bound = 0.015

      spatula_seed = np.array([
                              [0.4, -0.22, -0.89, -1.41],
                              [-0.63, 0.64, -0.44, -1.78],
                              [0.67, 0.74, 0.11, 0],
                              [0, 0, 0, 1]
                              ])

      sugar_box_seed = np.array([
                                [0.77, -0.53, 0.35, -1.97],
                                [0.58, 0.35, -0.74, -1.74],
                                [0.26, 0.77, 0.58, -0.01],
                                [0, 0, 0, 1]
                                ])

      apple_seed = np.array([
                            [0.09, -0.48, 0.87, -2.14],
                            [0.19, 0.87, 0.46, -0.57],
                            [-0.98, 0.12, 0.17, -0.16],
                            [0, 0, 0, 1]
                            ])

      object_pairs = [(spatula_scene, spatula_model),
                      (sugar_box_scene, sugar_box_model),
                      (apple_scene, apple_model)]

      seeds = (spatula_seed, sugar_box_seed, apple_seed)

      for i, object_pair in enumerate(object_pairs):
        actual_X_BA, actual_mean_error, _ = icp(object_pair[0],
                                                object_pair[1],
                                                init_guess=seeds[i],
                                                max_iterations=20,
                                                tolerance=1e-3)


        self.assertTrue(
                np.allclose(np.around(actual_X_BA, decimals=2), seeds[i]),
                "".join([
                    "actual transform = ",
                    np.array_str(np.around(actual_X_BA, decimals=2)),
                    " was not close to the expected transform = ",
                    np.array_str(seeds[i])
                    ])
            )

        self.assertLess(
                actual_mean_error, expected_error_upper_bound,
                "".join([
                    "actual mean error = ",
                    str(actual_mean_error),
                    " was not less than the error upper bound = ",
                    str(expected_error_upper_bound)
                    ])
            )

    @weight(8)
    @timeout_decorator.timeout(60.0)
    def test_03_seeded_repeated_icp(self):
      '''Repeated_ICP_converges_when_initial_guess_is_final_transform'''
      from iterative_closest_point import (nearest_neighbors,
                                           least_squares_transform,
                                           repeat_icp_until_good_fit)

      spatula_model = np.load("resources/spatula_model.npy")
      spatula_scene = np.load("resources/spatula_scene.npy")

      sugar_box_model = np.load("resources/sugar_box_model.npy")
      sugar_box_scene = np.load("resources/sugar_box_scene.npy")

      apple_model = np.load("resources/apple_model.npy")
      apple_scene = np.load("resources/apple_scene.npy")

      expected_error_upper_bound = 0.015

      spatula_seed = np.array([
                              [0.4, -0.22, -0.89, -1.41],
                              [-0.63, 0.64, -0.44, -1.78],
                              [0.67, 0.74, 0.11, 0],
                              [0, 0, 0, 1]
                              ])

      sugar_box_seed = np.array([
                                [0.77, -0.53, 0.35, -1.97],
                                [0.58, 0.35, -0.74, -1.74],
                                [0.26, 0.77, 0.58, -0.01],
                                [0, 0, 0, 1]
                                ])

      apple_seed = np.array([
                            [0.09, -0.48, 0.87, -2.14],
                            [0.19, 0.87, 0.46, -0.57],
                            [-0.98, 0.12, 0.17, -0.16],
                            [0, 0, 0, 1]
                            ])

      object_pairs = [(spatula_scene, spatula_model),
                      (sugar_box_scene, sugar_box_model),
                      (apple_scene, apple_model)]

      seeds = (spatula_seed, sugar_box_seed, apple_seed)

      for i, object_pair in enumerate(object_pairs):
        actual_X_BA, actual_mean_error, _ = \
          repeat_icp_until_good_fit(object_pair[0],
                                    object_pair[1],
                                    error_threshold=expected_error_upper_bound,
                                    max_tries=3,
                                    init_guess=seeds[i],
                                    max_iterations=20,
                                    tolerance=1e-3)

        self.assertTrue(
                np.allclose(np.around(actual_X_BA, decimals=2), seeds[i]),
                "".join([
                    "actual transform = ",
                    np.array_str(np.around(actual_X_BA, decimals=2)),
                    " was not close to the expected transform = ",
                    np.array_str(seeds[i])
                    ])
            )

        self.assertLess(
                actual_mean_error, expected_error_upper_bound,
                "".join([
                    "actual mean error = ",
                    str(actual_mean_error),
                    " was not less than the error upper bound = ",
                    str(expected_error_upper_bound)
                    ])
            )


class TestPset2_PickAndPlacePerceptionTest(unittest.TestCase):
    def setUp(self):
        self.scene_point_cloud = np.load('./resources/scene_point_cloud.npy')

    @weight(4)
    @timeout_decorator.timeout(10.0)
    def test_00_estimate_bottle_pose(self):
        '''icp_returns_correct_bottle_segmentation'''
        from kuka_multibody_sim_w_control import table_top_z_in_world
        from point_cloud_processing import (SegmentBottleZfilter,
                                            bottle_center_initial_guess,
                                            FindBottlePointInCroppedScenePointCloud)

        scene_point_cloud = np.load('./resources/scene_point_cloud.npy')
        scene_point_cloud_cropped =\
            SegmentBottleZfilter(scene_point_cloud, z_threshold=table_top_z_in_world + 0.001)

        # create a random transformation
        R = np.array([[0., 0, 1],
                      [1., 0, 0],
                      [0., 1, 0]])
        t = np.random.rand(3)
        X = Isometry3.Identity()
        X.set_rotation(R)
        X.set_translation(t)

        # apply random transformation to scene and initial guess
        scene_point_cloud_transfomed = R.dot(scene_point_cloud_cropped.T) + t.reshape(3,1)
        scene_point_cloud_transfomed = scene_point_cloud_transfomed.T
        bottle_center_initial_guess_transformed = X.multiply(bottle_center_initial_guess)

        indices_bottle = FindBottlePointInCroppedScenePointCloud(
            scene_point_cloud_transfomed, bottle_center_initial_guess_transformed)

        num_points = len(indices_bottle)
        self.assertTrue(14900 < num_points and num_points < 15000,
                        "Your cluster has %d points. The bottle cluster should have "
                        "14900~15000 points"%num_points )

        mean = np.zeros(3)
        for point in scene_point_cloud_cropped[indices_bottle]:
            mean += point

        mean /= num_points

        self.assertTrue(np.linalg.norm(mean - bottle_center_initial_guess) < 0.15,
                        "The mean of your segmented point cloud is too far away from where the bottle is.")



class TestPset2_PickAndPlacePlanningTest(unittest.TestCase):
    @weight(16)
    @timeout_decorator.timeout(150.0)
    def test_00_pick_and_place(self):
        '''pick_and_place_satisfies_all_requirements'''
        from kuka_multibody_sim_w_control import (CreateMultiBodyPlant,
                                                  RunSimulation,)

        from kuka_pick_and_place_trajectory_generation import \
            (GenerateIiwaTrajectoriesAndGripperSetPoints, p_WQ_home, p_EQ)
        # Run simulation
        plant, scene_graph, model_list = CreateMultiBodyPlant()
        q_traj_list, gripper_setpoint_list = \
            GenerateIiwaTrajectoriesAndGripperSetPoints(
                plant, model_list, X_WObject, X_WBox, is_printing=False)
        state_log = RunSimulation(plant, scene_graph, q_traj_list, gripper_setpoint_list,
                                 is_test=True, real_time_rate=0.0)

        # Create context for final state
        x_final = state_log.data()[:, -1].flatten()
        # x_final = np.load("x_final.npy")
        context = plant.CreateDefaultContext()
        tree = plant.tree()
        x_mutalbe = tree.get_mutable_multibody_state_vector(context)
        x_mutalbe[:] = x_final
        world_frame = plant.world_frame()

        # Point Q in EE frame returns to p_WQ_home
        X_WE = tree.CalcRelativeTransform(
            context, frame_A=world_frame, frame_B=plant.GetFrameByName("body"))
        p_WQ = X_WE.multiply(p_EQ)
        self.assertTrue(np.abs(p_WQ_home - p_WQ).max()<0.03,
                        "Point Q is too far away from p_WQ_home. "
                        "p_WQ is [%f, %f, %f], p_WQ_home is [%f, %f, %f]"\
                        %(p_WQ[0], p_WQ[1], p_WQ[2], p_WQ_home[0], p_WQ_home[1], p_WQ_home[2]))

        # Box does not move too much from its initial pose.
        X_WBox_final = tree.CalcRelativeTransform(
            context, frame_A=world_frame, frame_B=plant.GetFrameByName("base_link"))
        R_WBox_final = X_WBox_final.rotation()
        p_WBox_final = X_WBox_final.translation()

        is_rotation_close = np.abs(np.eye(3) - R_WBox_final).max() < 0.01
        is_position_close = np.abs(p_WBoxO - p_WBox_final).max() < 0.02
        self.assertTrue(is_rotation_close and is_position_close,
                        "Box moves too much from its initial pose.")

        # velocity of everything should be close to zero
        v = x_final[plant.num_positions():]
        v_max = np.abs(v).max()
        self.assertTrue(v_max < 0.02,
                        "Velocity of some bodies is not close to zero. "
                        "Maximum velocity is %f."%v_max)

        # Gripper must be open
        gripper_joint = plant.GetJointByName("left_finger_sliding_joint")
        joint_displacement = gripper_joint.get_translation(context)
        self.assertTrue(np.abs(joint_displacement) > 0.04,
                        "Gripper is not fully open.")

        # Origin of bottle frame must be above (z) and within (x,y) the top surface of the box.
        X_WBottle = tree.CalcRelativeTransform(
            context, frame_A=world_frame, frame_B=plant.GetFrameByName("base_link_bottle"))
        p_WBottle_final = X_WBottle.translation()

        x_bottle = p_WBottle_final[0]
        y_bottle = p_WBottle_final[1]
        z_bottle = p_WBottle_final[2]

        x_box = p_WBox_final[0]
        y_box = p_WBox_final[1]
        z_box = p_WBox_final[2]

        self.assertTrue(z_bottle > z_box + 0.145,
                        "Origin of the bottle body frame is below the top face of the box.")
        self.assertTrue(np.abs(y_bottle - y_box) < 0.075 and np.abs(x_bottle - x_box) < 0.1,
                        "Origin of the bottle body frame is not inside the top face of the box.")


class TestPset2_PickAndPlacePerceptionBonusTest(unittest.TestCase):
    @weight(6)
    @timeout_decorator.timeout(200.0)
    def test_00_estimate_bottle_pose(self):
        '''BONUS_QUESTION_icp_reliably_returns_correct_box_pose'''
        from kuka_multibody_sim_w_control import X_WBox
        from point_cloud_processing import (GetBoxModelPointCloud,
                                            EstimateBoxPoseSmartly)

        R_WB = X_WBox.rotation()
        p_WBo = X_WBox.translation()
        scene_point_cloud = np.load('./resources/scene_point_cloud.npy')

        success_count = 0
        for i in range(10):
            i += 1
            box_point_cloud_model = GetBoxModelPointCloud(num_points=10000)
            X_MS_box =EstimateBoxPoseSmartly(box_point_cloud_model, scene_point_cloud)
            X_WB = np.linalg.inv(X_MS_box)
            R_WB_estimated = X_WB[0:3, 0:3]
            p_WBo_estimated = X_WB[0:3, 3]

            is_rotation_close = np.abs(R_WB - R_WB_estimated).max() < 0.02
            is_position_close = np.abs(p_WBo - p_WBo_estimated).max() < 0.02

            if is_position_close and is_rotation_close:
                success_count += 1


        self.assertTrue(success_count >= 8, "Your pose estimation only succeeds %d out of 10 times."%success_count)


def pretty_format_json_results(test_output_file):
    import json
    import textwrap

    output_str = ""

    try:
        with open(test_output_file, "r") as f:
            results = json.loads(f.read())
 
        total_score_possible = 0.0

        if "tests" in results.keys():
            for test in results["tests"]:
                output_str += "Test %s: " % (test["name"])
                output_str += "%2.2f/%2.2f.\n" % (test["score"], test["max_score"])
                total_score_possible += test["max_score"]
                if "output" in test.keys():
                    output_str += "  * %s\n" % (
                        textwrap.fill(test["output"], 70,
                                      subsequent_indent = "  * "))
                output_str += "\n"

            output_str += "TOTAL SCORE (automated tests only): %2.2f/%2.2f\n" % (results["score"], total_score_possible)

        else:
            output_str += "TOTAL SCORE (automated tests only): %2.2f\n" % (results["score"])
            if "output" in results.keys():
                output_str += "  * %s\n" % (
                        textwrap.fill(results["output"], 70,
                                      subsequent_indent = "  * "))
                output_str += "\n"
    
    except IOError:
        output_str += "No such file %s" % test_output_file
    except Exception as e:
        output_str += "Other exception while printing results file: ", e

    return output_str

def global_fail_with_error_message(msg, test_output_file):
    import json

    results = {"score": 0.0,
               "output": msg}

    with open(test_output_file, 'w') as f:
        f.write(json.dumps(results,
                           indent=4,
                           sort_keys=True,
                           separators=(',', ': '),
                           ensure_ascii=True))

def run_tests(test_output_file = "test_results.json"):
    try:
        # Check for existence of the expected files
        expected_files = [
        ]
        for file in expected_files:
            if not os.path.isfile(file):
                raise ValueError("Couldn't find an expected file: %s" % file)

        do_testing = True

    except Exception as e:
        import traceback
        global_fail_with_error_message("Somehow failed trying to import the files needed for testing " +
                                       traceback.format_exc(1), test_output_file)
        do_testing = False

    if do_testing:
        test_cases = [TestPset2_BasicICPTest,
                      TestPset2_PickAndPlacePerceptionTest,
                      TestPset2_PickAndPlacePerceptionBonusTest,
                      TestPset2_PickAndPlacePlanningTest]

        suite = unittest.TestSuite()
        for test_class in test_cases:
            tests = unittest.defaultTestLoader.loadTestsFromTestCase(test_class)
            suite.addTests(tests)

        with open(test_output_file, "w") as f:
            JSONTestRunner(stream=f).run(suite)

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print "Please invoke with one argument: the result json to write."
        print "(This test file assumes it's in the same directory as the code to be tested."
        exit(1)

    run_tests(test_output_file=sys.argv[1])

