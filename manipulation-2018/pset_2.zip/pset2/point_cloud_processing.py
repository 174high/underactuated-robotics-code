import numpy as np
from iterative_closest_point import make_meshcat_color_array
import meshcat.geometry as g
from kuka_multibody_sim_w_control import table_top_z_in_world

bottle_center_initial_guess = np.array([0.8, 0, table_top_z_in_world])

'''
cropped_scene_point_cloud: (N,3) numpy array 
    the z-filtered point cloud of the scene.
center_initial_guess: (3,) numpy array 
    initial belief of the center of the bottle point cloud
return value:
    a python list of the indices of points in cropped_scene_point_cloud
    that belong to the bottle. 
'''
def FindBottlePointInCroppedScenePointCloud(
        cropped_scene_point_cloud, bottle_center_initial_guess):
    num_clusters = 3
    #Your code here:
    ################################################

    return [0,1]

'''
box_point_cloud_model and scene_point_cloud are (N,3) numpy arrays of point clouds.
return value:
    A uniform transformation matrix in the form of a (4,4) numpy array, which describes
    the transformation from the scene point cloud to the model point cloud. 
'''
def EstimateBoxPoseSmartly(box_point_cloud_model, scene_point_cloud):
    X_MS = np.eye(4)
    # Put your box pose estimation here!


    return X_MS



def VisualizeTransformedScenePointCloud(X_MS, scene_point_cloud, vis):
    scene_point_cloud = scene_point_cloud.T
    # Create a copy of the observed point cloud that is homogenous
    # so we can apply a 4x4 homogenous transform to it.
    n_scene = scene_point_cloud.shape[1]
    homogenous_scene = np.ones((4, n_scene))
    homogenous_scene[:3, :] = np.copy(scene_point_cloud)

    # Apply the returned transformation to the observed samples to align the observed
    # point cloud with the ground truth point cloud.
    transformed_scene_point_cloud = X_MS.dot(homogenous_scene)

    # Create a yellow meshcat point cloud for visualization.
    vis['transformed_scene'].set_object(
        g.PointCloud(transformed_scene_point_cloud[:3, :],
                     make_meshcat_color_array(n_scene, 1.0, 1.0, 0.0),
                     size=0.001))


def SegmentBottleZfilter(scene_point_cloud, z_threshold=0.0):
    scene_point_cloud_cropped = np.zeros(scene_point_cloud.shape)
    point_count = 0
    for point in scene_point_cloud:
        if point[2] > z_threshold:
            scene_point_cloud_cropped[point_count] = point
            point_count += 1
    return scene_point_cloud_cropped[:point_count]


def SegmentBox(scene_point_cloud):
    scene_point_cloud_cropped = np.zeros(scene_point_cloud.shape)
    point_count = 0
    for point in scene_point_cloud:
        x = point[0]
        y = point[1]
        z = point[2]
        if z >= table_top_z_in_world+0.005 and np.abs(x-0.55) <= 0.11 and np.abs(y+0.28) <= 0.08:
            scene_point_cloud_cropped[point_count] = point
            point_count += 1
    return scene_point_cloud_cropped[:point_count]

'''
This function uniformly samples points from the faces of a box.
The number of points on each surface is proportional to the area of that surface.
num_points: integer
    Number of points in the returned point cloud.
return value: 
    np array of shape (3, num_points) 
'''
def GetBoxModelPointCloud(num_points):
    def get_point_from_bottom():
        x = np.random.rand() * 0.2 + (-0.1)
        y = np.random.rand() * 0.15 + (-0.075)
        z = 0
        return np.array([x, y, z])

    def get_point_from_top():
        x = np.random.rand() * 0.2 + (-0.1)
        y = np.random.rand() * 0.15 + (-0.075)
        z = 0.15
        return np.array([x, y, z])

    def get_point_from_front():
        x = 0.1
        y = np.random.rand() * 0.15 + (-0.075)
        z = np.random.rand() * 0.15 + 0.
        return np.array([x, y, z])

    def get_point_from_back():
        x = -0.1
        y = np.random.rand() * 0.15 + (-0.075)
        z = np.random.rand() * 0.15 + 0.
        return np.array([x, y, z])

    def get_point_from_left():
        x = np.random.rand() * 0.2 + (-0.1)
        y = -0.075
        z = np.random.rand() * 0.15 + 0.
        return np.array([x, y, z])

    def get_point_from_right():
        x = np.random.rand() * 0.2 + (-0.1)
        y = 0.075
        z = np.random.rand() * 0.15 + 0.
        return np.array([x, y, z])

    num_faces = 6
    get_points = [get_point_from_bottom,
                  get_point_from_top,
                  get_point_from_front,
                  get_point_from_back,
                  get_point_from_left,
                  get_point_from_right]

    areas = np.array([0.2 * 0.15,
                      0.2 * 0.15,
                      0.15 ** 2,
                      0.15 ** 2,
                      0.2 * 0.15,
                      0.2 * 0.15])

    normalized_areas = areas / areas.sum()
    weights = np.zeros(num_faces + 1)
    for i in range(num_faces):
        weights[i + 1] = weights[i] + normalized_areas[i]

    points = np.zeros((num_points, 3))

    for i in range(num_points):
        seed = np.random.rand()
        idx_face = 0
        while True:
            if seed > weights[idx_face] and seed < weights[idx_face + 1]:
                break
            idx_face += 1
        points[i] = get_points[idx_face]()

    return points
