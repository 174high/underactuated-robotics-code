# %%
import numpy as np
import os

from pydrake.common import FindResourceOrThrow
from pydrake.geometry import SceneGraph
from pydrake.multibody.multibody_tree import (UniformGravityFieldElement,
                                              WeldJoint, )
from pydrake.multibody.multibody_tree.multibody_plant import MultibodyPlant
from pydrake.multibody.multibody_tree.parsing import AddModelFromSdfFile
from pydrake.systems.framework import DiagramBuilder
from pydrake.systems.analysis import Simulator
from pydrake.util.eigen_geometry import Isometry3
from pydrake.math import RollPitchYaw, RotationMatrix

from pydrake.systems.primitives import SignalLogger
from kuka_multibody_controllers import (KukaMultibodyController,
                                        HandController,
                                        ManipStateMachine)

from underactuated.meshcat_visualizer import MeshcatVisualizer

#%%
def ForwardKinematicsMbp(x, frame, mbp):
    assert len(x) == mbp.num_positions() + mbp.num_velocities()
    context = mbp.CreateDefaultContext()
    tree = mbp.tree()
    x_mutalbe = tree.get_mutable_multibody_state_vector(context)
    x_mutalbe[:] = x

    world_frame = mbp.world_frame()

    X_WE = tree.CalcRelativeTransform(
        context, frame_A=world_frame, frame_B=frame)

    return X_WE


def RenderSystemWithGraphviz(system, output_file="system_view.gz"):
    ''' Renders the Drake system (presumably a diagram,
    otherwise this graph will be fairly trivial) using
    graphviz to a specified file. '''
    from graphviz import Source
    string = system.GetGraphvizString()
    src = Source(string)
    src.render(output_file, view=False)

#%%
table_top_z_in_world = 0.736 + 0.057 / 2

# initial poses for apple and box
X_WObject = Isometry3.Identity()
X_WObject.set_translation([0.8, 0, table_top_z_in_world])
X_WBox = Isometry3.Identity()
X_WBox.set_translation([0.55, -0.28, table_top_z_in_world])


iiwa_model = None
object_model = None
box_model = None
gripper_model = None

def CreateMultiBodyPlant():
    iiwa_sdf_path = FindResourceOrThrow(
        "drake/manipulation/models/iiwa_description/"
        "sdf/iiwa14_no_collision.sdf")
    wsg50_sdf_path = FindResourceOrThrow(
        "drake/manipulation/models/"
        "wsg_50_description/sdf/schunk_wsg_50.sdf")
    table_sdf_path = FindResourceOrThrow(
        "drake/examples/kuka_iiwa_arm/models/table/"
        "extra_heavy_duty_table_surface_only_collision.sdf")
    object_sdf_path = os.path.join(os.getcwd(),
        "models", "bleach_bottle.sdf")
    box_sdf_path = os.path.join(os.getcwd(),
        "models", "pedestal.sdf")

    # construct multibodyplant
    timestep = 0.0002
    plant = MultibodyPlant(timestep)
    scene_graph = SceneGraph()

    # Add models
    global iiwa_model, object_model, box_model, gripper_model
    iiwa_model = AddModelFromSdfFile(
        file_name=iiwa_sdf_path, model_name='robot',
        scene_graph=scene_graph, plant=plant)
    gripper_model = AddModelFromSdfFile(
        file_name=wsg50_sdf_path, model_name='gripper',
        scene_graph=scene_graph, plant=plant)
    table_model = AddModelFromSdfFile(
        file_name=table_sdf_path, model_name='table',
        scene_graph=scene_graph, plant=plant)
    table2_model = AddModelFromSdfFile(
        file_name=table_sdf_path, model_name='table2',
        scene_graph=scene_graph, plant=plant)
    object_model = AddModelFromSdfFile(
        file_name=object_sdf_path, model_name='object',
        scene_graph=scene_graph, plant=plant)
    box_model = AddModelFromSdfFile(
        file_name=box_sdf_path, model_name='box',
        scene_graph=scene_graph, plant=plant)

    # Define weld(fixed) joints
    X_Link7Ee = Isometry3.Identity()
    X_Link7Ee.set_translation([0, 0, 0.081])
    X_Link7Ee.set_rotation(RollPitchYaw(np.pi / 2, 0, np.pi / 2).ToRotationMatrix().matrix())

    # weld_gripper_to_robot_ee
    plant.WeldFrames(
        A=plant.GetFrameByName("iiwa_link_7", iiwa_model),
        B=plant.GetFrameByName("body", gripper_model),
        X_AB=X_Link7Ee)

    # weld_table_to_world
    plant.WeldFrames(
        A=plant.world_frame(),
        B=plant.GetFrameByName("link", table_model))

    # weld_robot_to_world
    X_WRobot = Isometry3.Identity()
    X_WRobot.set_translation([0, 0, table_top_z_in_world])
    plant.WeldFrames(
        A=plant.world_frame(),
        B=plant.GetFrameByName("iiwa_link_0", iiwa_model),
        X_AB=X_WRobot)

    # weld_table2_to_world
    X_WTable2 = Isometry3.Identity()
    X_WTable2.set_translation([0.8, 0, 0])
    plant.WeldFrames(
        A=plant.world_frame(),
        B=plant.GetFrameByName("link", table2_model),
        X_AB=X_WTable2)

    # Add gravity
    plant.AddForceElement(UniformGravityFieldElement([0, 0, -9.81]))

    plant.Finalize(scene_graph)
    assert plant.geometry_source_is_registered()

    return plant, scene_graph, [iiwa_model, object_model, box_model, gripper_model]




def RunSimulation(plant, scene_graph, q_traj_list, gripper_setpoint_list,
                  is_test=False, real_time_rate=1.0):
    if not is_test:
        print "Warning: if you have not yet run meshcat-server in another " \
              "terminal, this will hang."

    builder = DiagramBuilder()
    builder.AddSystem(scene_graph)
    builder.AddSystem(plant)

    # Add meshcat visualizer if not in test mode
    viz = None
    if not is_test:
        viz = MeshcatVisualizer(scene_graph)
        builder.AddSystem(viz)
        builder.Connect(scene_graph.get_pose_bundle_output_port(),
                        viz.get_input_port(0))

    # Connect scene_graph to MBP for collision detection.
    builder.Connect(
        plant.get_geometry_poses_output_port(),
        scene_graph.get_source_pose_port(plant.get_source_id()))
    builder.Connect(
        scene_graph.get_query_output_port(),
        plant.get_geometry_query_input_port())

    # Add iiwa controller
    print_period = 0.5
    if is_test:
        print_period = 0.0
    iiwa_controller = KukaMultibodyController(plant=plant,
                                              kuka_model_instance=iiwa_model,
                                              print_period=print_period)
    builder.AddSystem(iiwa_controller)
    builder.Connect(iiwa_controller.get_output_port(0),
                    plant.get_input_port(0))
    builder.Connect(plant.get_continuous_state_output_port(),
                    iiwa_controller.robot_state_input_port)

    # Add hand controller
    hand_controller = HandController(plant=plant,
                                     model_instance=gripper_model)
    builder.AddSystem(hand_controller)
    builder.Connect(hand_controller.get_output_port(0),
                    plant.get_input_port(1))
    builder.Connect(plant.get_continuous_state_output_port(),
                    hand_controller.robot_state_input_port)

    # Add state machine
    state_machine = ManipStateMachine(plant, q_traj_list, gripper_setpoint_list)
    builder.AddSystem(state_machine)
    builder.Connect(plant.get_continuous_state_output_port(),
                    state_machine.robot_state_input_port)
    builder.Connect(state_machine.kuka_plan_output_port,
                    iiwa_controller.plan_input_port)
    builder.Connect(state_machine.hand_setpoint_output_port,
                    hand_controller.setpoint_input_port)

    # Add logger
    state_log = builder.AddSystem(SignalLogger(plant.get_continuous_state_output_port().size()))
    state_log._DeclarePeriodicPublish(0.02)
    builder.Connect(plant.get_continuous_state_output_port(), state_log.get_input_port(0))

    # Build diagram.
    diagram = builder.Build()
    if not is_test:
        viz.load()

    # generate system diagram using graphviz if not in test mode
    if not is_test:
        RenderSystemWithGraphviz(diagram, "view.gv")

    # Create simulation diagram context
    diagram_context = diagram.CreateDefaultContext()
    mbp_context = diagram.GetMutableSubsystemContext(
        plant, diagram_context)

    # set initial pose for the object and the box.
    tree = plant.tree()
    tree.SetFreeBodyPoseOrThrow(
        plant.GetBodyByName("base_link_bottle", object_model), X_WObject, mbp_context)
    tree.SetFreeBodyPoseOrThrow(
        plant.GetBodyByName("base_link", box_model), X_WBox, mbp_context)

    # set initial posture of the iiwa arm.
    q0 = q_traj_list[0].value(0)
    for i, joint_angle in enumerate(q0):
        iiwa_joint = plant.GetJointByName("iiwa_joint_%d" % (i + 1))
        iiwa_joint.set_angle(context=mbp_context, angle=joint_angle)

    simulator = Simulator(diagram, diagram_context)
    simulator.set_publish_every_time_step(False)
    simulator.set_target_realtime_rate(real_time_rate)
    simulator.Initialize()

    # Run simulation
    sim_duration = 0.
    for q_traj in q_traj_list:
        sim_duration += q_traj.end_time() + 0.5
    sim_duration += 5.0
    simulator.StepTo(sim_duration)

    return state_log



