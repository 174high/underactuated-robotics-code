# Written by Patricia Suriana, MIT ca. 2013
# Modified by Tomas Lozano-Perez, MIT ca 2016

import pddl_parser
import search
import time
import sys
import pdb

def printOutputVerbose(tic, toc, plan, cost, final_state, goal):
  print "\n******************************FINISHED TEST******************************"
  print "Goals: "
  for state in goal:
    print "\t" + str(state)
  print '\nRunning time: ', (toc-tic), 's'
  if plan == None:
    print '\tNO PLAN FOUND'
  else:
    print "\nNumber of Actions: ", len(plan)
    print '\nCost:', cost
    print "\nPlan: "
    for op in plan:
      print "\t" + repr(op)
    print "\nFinal States:"
    for state in final_state:
      print "\t" + str(state)
  print "*************************************************************************\n"

def printOutput(tic, toc, plan, cost):
  print (toc-tic), '\t', len(plan), '\t', cost

class PlanProblem(search.Problem):
  def __init__(self, task):
    '''A task planning problem.

    Args:
      task: a strips.Task instance
    '''
    search.Problem.__init__(self, task.initial_state)
    self.task = task

  def actions(self, state):
    return self.task.get_successor_ops(state)

  def result(self, state, action):
    return action.apply(state)

  def goal_test(self, state):
    return self.task.goal_reached(state)

  def h(self, node):
    '''A heuristic function of this PlanProblem's task.

    Args:
      node: search.Node encoding a state in the search

    Returns: value of some heuristic that estimates
      length of path from the input state to the goal of the task

    '''
    return self.h_FF(node)

  def h_FF(self, node):
    '''The h_FF heuristic function of this PlanProblem's task.

    Args:
      node: search.Node encoding a state in the search

    Returns: int value of h_FF from the node to the goal of the task

    '''
    #####################
    # Your code here

    return 0
    #####################

def run_planner(task):
  '''Run the given task.

  Args:
    task: a strips.Task instance to run.

  Returns:
    final_state: frozenset of the tuples representing the
      state at the end of the plan
    plan: a list of strips.Operator instances representing the
      actions taken to complete the task
    cost: int. the cost of plan
  '''
  prob = PlanProblem(task)
  final_node = search.astar_search(prob)

  ffv = prob.h(search.Node(task.initial_state))
  print 'h(initial) =', ffv

  # final_state - the final state at the end of the plan
  # plan - a list of actions representing the plan
  # cost - the cost of the plan
  final_state = final_node.state
  plan = final_node.solution()
  cost = final_node.path_cost

  print plan

  return final_state, plan, cost

if __name__ == "__main__":
  args = sys.argv
  if len(args) != 3:                    # default task
    dirName = "prodigy-bw"
    fileName = "bw-simple"
  else:
    dirName = args[1]
    fileName = args[2]
  domain_file = dirName + '/domain.pddl'
  problem_file = dirName + '/' + fileName + '.pddl'

  # task is an instance of the Task class defined in strips.py
  task = pddl_parser.parse(domain_file, problem_file)

  # This should be commented out for larger tasks
  print task

  print "\n******************************START TEST******************************"

  tic = time.time()
  final_state, plan, cost = run_planner(task)
  toc = time.time()

  printOutputVerbose(tic, toc, plan, cost, final_state, task.goals)


#############################################
# Please describe your testing strategy below in comments
