import os
import sys
import timeout_decorator
import unittest
from math import pi

from gradescope_utils.autograder_utils.decorators import weight
from gradescope_utils.autograder_utils.json_test_runner import JSONTestRunner


class TestPset4_RRTTest(unittest.TestCase):

    @weight(2)
    @timeout_decorator.timeout(120.0)
    def test_00_robot_rrt_works(self):
        '''RRT gives a solution on a simple planar problem'''

        from rrt_planner.geometry import Point, Polygon, Object
        from rrt_planner.robot import Robot, RobotArm, Range, ConfigurationSpace
        from rrt_planner.rrt_planning import Problem
        
        robot = Robot([ \
            Polygon([Point(-2, -1), Point(2, -1), Point(2, 1), Point(-2, 1)]),
            Polygon([Point(-1, 1), Point(1, 1), Point(0, 2)])
        ])

        start = (5.0, 5.0, 0)
        goal = (15.0, 15.0, pi/2)

        cspace = ConfigurationSpace([ \
            Range(0, 20), \
            Range(0, 20), \
            Range(-pi, pi, wrap_around = True)
        ], start, robot.distance, 3*[0.25])

        obstacles = [Object(Point(10, 10),
                          [Polygon([Point(0, -2), Point(2, 0),
                                    Point(0, 2), Point(-2, 0)])])]   
        problem = Problem(20, 20, robot, obstacles, start, goal, cspace, display_tree = False)

        passed = False

        for _ in range(5):
          path_found = problem.run_and_display('rrt', display=False)
          if path_found:
            passed = True
            break

        self.assertTrue(passed,
                        "RRT planner didn't find a solution with 5 tries")

    @weight(2)
    @timeout_decorator.timeout(120.0)
    def test_01_robot_birrt_works(self):
        '''Bidirectional RRT gives a solution on a simple planar problem'''
        
        from rrt_planner.geometry import Point, Polygon, Object
        from rrt_planner.robot import Robot, RobotArm, Range, ConfigurationSpace
        from rrt_planner.rrt_planning import Problem

        robot = Robot([ \
            Polygon([Point(-2, -1), Point(2, -1), Point(2, 1), Point(-2, 1)]),
            Polygon([Point(-1, 1), Point(1, 1), Point(0, 2)])
        ])

        start = (5.0, 5.0, 0)
        goal = (15.0, 15.0, pi/2)

        cspace = ConfigurationSpace([ \
            Range(0, 20), \
            Range(0, 20), \
            Range(-pi, pi, wrap_around = True)
        ], start, robot.distance, 3*[0.25])

        obstacles = [Object(Point(10, 10),
                          [Polygon([Point(0, -2), Point(2, 0),
                                    Point(0, 2), Point(-2, 0)])])]   
        problem = Problem(20, 20, robot, obstacles, start, goal, cspace, display_tree = False)

        passed = False

        for _ in range(5):
          path_found = problem.run_and_display('birrt', display=False)
          if path_found:
            passed = True
            break

        self.assertTrue(passed,
                        "Bidirectional RRT planner didn't find a solution with 5 tries")

    @weight(2)
    @timeout_decorator.timeout(120.0)
    def test_02_arm_rrt_works(self):
        '''RRT gives a solution on a simple arm problem'''

        from rrt_planner.geometry import Point, Polygon, Object
        from rrt_planner.robot import Robot, RobotArm, Range, ConfigurationSpace
        from rrt_planner.rrt_planning import Problem

        def create_link(length, width):
            return Polygon([Point(0, -width/2.0), Point(length, -width/2.0),
                      Point(length, width/2.0), Point(0, width/2.0)])

        robot = RobotArm(Point(10, 10), [
            (Point(-.5, 0), create_link(4, 1)),
            (Point(3.5, 0), create_link(3, 1)),
            (Point(2.5, 0), create_link(2, 1))
        ])

        start = (pi/2, pi/2, -pi/4)
        goal = (pi/4, -pi/6, -pi/3)

        cspace = ConfigurationSpace([
            Range(-pi/2, pi/2),
            Range(-pi/2, pi/2),
            Range(-pi/2, pi/2)
        ], start, robot.distance, 3*[0.25])

        obstacles = [Object(Point(12, 17.5),
                          [Polygon([Point(0, -2), Point(2, 0),
                                    Point(0, 2), Point(-2, 0)])]),
                   Object(Point(16, 16),
                          [Polygon([Point(0, -2), Point(2, 0),
                                    Point(0, 2), Point(-2, 0)])])]   
        problem = Problem(20, 20, robot, obstacles, start, goal, cspace)

        passed = False

        for _ in range(5):
          path_found = problem.run_and_display('rrt', display=False)
          if path_found:
            passed = True
            break

        self.assertTrue(passed,
                        "RRT planner didn't find a solution with 5 tries")

    @weight(2)
    @timeout_decorator.timeout(120.0)
    def test_03_arm_birrt_works(self):
        '''Bidirectional RRT gives a solution on a simple arm problem'''

        from rrt_planner.geometry import Point, Polygon, Object
        from rrt_planner.robot import Robot, RobotArm, Range, ConfigurationSpace
        from rrt_planner.rrt_planning import Problem
        
        def create_link(length, width):
            return Polygon([Point(0, -width/2.0), Point(length, -width/2.0),
                      Point(length, width/2.0), Point(0, width/2.0)])

        robot = RobotArm(Point(10, 10), [
            (Point(-.5, 0), create_link(4, 1)),
            (Point(3.5, 0), create_link(3, 1)),
            (Point(2.5, 0), create_link(2, 1))
        ])

        start = (pi/2, pi/2, -pi/4)
        goal = (pi/4, -pi/6, -pi/3)

        cspace = ConfigurationSpace([
            Range(-pi/2, pi/2),
            Range(-pi/2, pi/2),
            Range(-pi/2, pi/2)
        ], start, robot.distance, 3*[0.25])

        obstacles = [Object(Point(12, 17.5),
                          [Polygon([Point(0, -2), Point(2, 0),
                                    Point(0, 2), Point(-2, 0)])]),
                   Object(Point(16, 16),
                          [Polygon([Point(0, -2), Point(2, 0),
                                    Point(0, 2), Point(-2, 0)])])]   
        problem = Problem(20, 20, robot, obstacles, start, goal, cspace)

        passed = False

        for _ in range(5):
          path_found = problem.run_and_display('birrt', display=False)
          if path_found:
            passed = True
            break

        self.assertTrue(passed,
                        "Bidirectional RRT planner didn't find a solution with 5 tries")

class TestPset4_PDDLTest(unittest.TestCase):

    def pddl_task_test(self, task_file_name, expected_ffv):
        from pddl_planner.pddl_main import run_planner, PlanProblem
        from pddl_planner.pddl_parser import parse
        import pddl_planner.search as search
        
        domain_file = 'pddl_planner/prodigy-bw/domain.pddl'
        problem_file = 'pddl_planner/prodigy-bw/' + task_file_name + '.pddl'

        task = parse(domain_file, problem_file)

        final_state, plan, cost = run_planner(task)

        for goal in task.goals:
            self.assertTrue(goal in final_state,
                            "goal " + str(goal) + " not in final states " + str(final_state))

        prob = PlanProblem(task)

        ffv = prob.h(search.Node(task.initial_state))

        self.assertEqual(ffv, expected_ffv,
            "Your heuristic value of %d is not equal to the expected value of %d" % (ffv, expected_ffv))

    @weight(2)
    @timeout_decorator.timeout(60.0)
    def test_00_bw_simple(self):
        '''h_FF is correct for the bw-simple task'''

        self.pddl_task_test('bw-simple', 2)

    @weight(2)
    @timeout_decorator.timeout(60.0)
    def test_01_bw_sussman(self):
        '''h_FF is correct for the bw-sussman task'''

        self.pddl_task_test('bw-sussman', 5)

    @weight(2)
    @timeout_decorator.timeout(60.0)
    def test_02_bw_large_a(self):
        '''h_FF is correct for the bw-large-a task'''

        self.pddl_task_test('bw-large-a', 12)

    @weight(2)
    @timeout_decorator.timeout(60.0)
    def test_03_bw_large_b(self):
        '''h_FF is correct for the bw-large-b task'''

        self.pddl_task_test('bw-large-b', 16)

    @weight(2)
    @timeout_decorator.timeout(60.0)
    def test_04_bw_large_c(self):
        '''h_FF is correct for the bw-large-c task'''

        self.pddl_task_test('bw-large-c', 26)

    @weight(2)
    @timeout_decorator.timeout(60.0)
    def test_05_bw_large_d(self):
        '''h_FF is correct for the bw-large-d task'''

        self.pddl_task_test('bw-large-d', 34)

def pretty_format_json_results(test_output_file):
    import json
    import textwrap

    output_str = ""

    try:
        with open(test_output_file, "r") as f:
            results = json.loads(f.read())
 
        total_score_possible = 0.0

        if "tests" in results.keys():
            for test in results["tests"]:
                output_str += "Test %s: " % (test["name"])
                output_str += "%2.2f/%2.2f.\n" % (test["score"], test["max_score"])
                total_score_possible += test["max_score"]
                if "output" in test.keys():
                    output_str += "  * %s\n" % (
                        textwrap.fill(test["output"], 70,
                                      subsequent_indent = "  * "))
                output_str += "\n"

            output_str += "TOTAL SCORE (automated tests only): %2.2f/%2.2f\n" % (results["score"], total_score_possible)

        else:
            output_str += "TOTAL SCORE (automated tests only): %2.2f\n" % (results["score"])
            if "output" in results.keys():
                output_str += "  * %s\n" % (
                        textwrap.fill(results["output"], 70,
                                      subsequent_indent = "  * "))
                output_str += "\n"
    
    except IOError:
        output_str += "No such file %s" % test_output_file
    except Exception as e:
        output_str += "Other exception while printing results file: ", e

    return output_str

def global_fail_with_error_message(msg, test_output_file):
    import json

    results = {"score": 0.0,
               "output": msg}

    with open(test_output_file, 'w') as f:
        f.write(json.dumps(results,
                           indent=4,
                           sort_keys=True,
                           separators=(',', ': '),
                           ensure_ascii=True))

def run_tests(test_output_file = "test_results.json"):
    try:
        # Check for existence of the expected files
        expected_files = [
        ]
        for file in expected_files:
            if not os.path.isfile(file):
                raise ValueError("Couldn't find an expected file: %s" % file)

        do_testing = True

    except Exception as e:
        import traceback
        global_fail_with_error_message("Somehow failed trying to import the files needed for testing " +
                                       traceback.format_exc(1), test_output_file)
        do_testing = False

    if do_testing:
        test_cases = [TestPset4_RRTTest, TestPset4_PDDLTest]

        suite = unittest.TestSuite()
        for test_class in test_cases:
            tests = unittest.defaultTestLoader.loadTestsFromTestCase(test_class)
            suite.addTests(tests)

        with open(test_output_file, "w") as f:
            JSONTestRunner(stream=f).run(suite)

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print "Please invoke with one argument: the result json to write."
        print "(This test file assumes it's in the directory above the code to be tested."
        exit(1)

    run_tests(test_output_file=sys.argv[1])

    print pretty_format_json_results(sys.argv[1])

