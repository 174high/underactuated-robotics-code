import os
import imp
import sys
import timeout_decorator
import unittest
import math
import numpy as np
import random
from gradescope_utils.autograder_utils.decorators import weight
from gradescope_utils.autograder_utils.json_test_runner import JSONTestRunner


from kuka_multibody_sim import (SimulateRobotFreeFall,
                                your_apple_initial_position_in_world_frame,
                                your_robot_initial_joint_angles,
                                table_top_z_in_world,)


class TestPset1a_FallingTest(unittest.TestCase):
    @weight(5)
    @timeout_decorator.timeout(40.0)
    def test_00_apple_and_ee_on_table(self):
        '''apple_and_robot_end_effector_are_on_the_designated_table'''
        state_log, mbp =SimulateRobotFreeFall(
            your_apple_initial_position_in_world_frame,
            your_robot_initial_joint_angles,
            sim_duration=4.0, real_time_rate=0., is_test=True)

        context = mbp.CreateDefaultContext()
        tree = mbp.model()

        state_final = state_log.data()[:,-1]

        state = context.get_mutable_discrete_state_vector().get_mutable_value()
        state[:] = state_final[:]

        world_frame = mbp.world_frame()
        robot_ee_frame = mbp.GetBodyByName("body").body_frame()
        apple_frame = mbp.GetBodyByName("base_link_apple").body_frame()

        X_W_Apple = tree.CalcRelativeTransform(
            context, frame_A=world_frame, frame_B=apple_frame)
        X_W_EE = tree.CalcRelativeTransform(
            context, frame_A=world_frame, frame_B=robot_ee_frame)

        position_apple = X_W_Apple.translation()
        position_ee = X_W_EE.translation()
        self.assertTrue(position_apple[0] > 0.4, "Apple is not on the desired table.")
        self.assertTrue(position_apple[2] > table_top_z_in_world - 0.01, "Apple is not on any table.")
        self.assertTrue(position_ee[2] > table_top_z_in_world - 0.01, "Gripper is not on any table.")


def pretty_format_json_results(test_output_file):
    import json
    import textwrap

    output_str = ""

    try:
        with open(test_output_file, "r") as f:
            results = json.loads(f.read())
 
        total_score_possible = 0.0

        if "tests" in results.keys():
            for test in results["tests"]:
                output_str += "Test %s: " % (test["name"])
                output_str += "%2.2f/%2.2f.\n" % (test["score"], test["max_score"])
                total_score_possible += test["max_score"]
                if "output" in test.keys():
                    output_str += "  * %s\n" % (
                        textwrap.fill(test["output"], 70,
                                      subsequent_indent = "  * "))
                output_str += "\n"

            output_str += "TOTAL SCORE (automated tests only): %2.2f/%2.2f\n" % (results["score"], total_score_possible)

        else:
            output_str += "TOTAL SCORE (automated tests only): %2.2f\n" % (results["score"])
            if "output" in results.keys():
                output_str += "  * %s\n" % (
                        textwrap.fill(results["output"], 70,
                                      subsequent_indent = "  * "))
                output_str += "\n"
    
    except IOError:
        output_str += "No such file %s" % test_output_file
    except Exception as e:
        output_str += "Other exception while printing results file: ", e

    return output_str

def global_fail_with_error_message(msg, test_output_file):
    import json

    results = {"score": 0.0,
               "output": msg}

    with open(test_output_file, 'w') as f:
        f.write(json.dumps(results,
                           indent=4,
                           sort_keys=True,
                           separators=(',', ': '),
                           ensure_ascii=True))

def run_tests(test_output_file = "test_results.json"):
    try:
        # Check for existence of the expected files
        expected_files = [
        ]
        for file in expected_files:
            if not os.path.isfile(file):
                raise ValueError("Couldn't find an expected file: %s" % file)

        do_testing = True

    except Exception as e:
        import traceback
        global_fail_with_error_message("Somehow failed trying to import the files needed for testing " + traceback.format_exc(1), test_output_file)
        do_testing = False

    if do_testing:
        test_cases = [TestPset1a_FallingTest]

        suite = unittest.TestSuite()
        for test_class in test_cases:
            tests = unittest.defaultTestLoader.loadTestsFromTestCase(test_class)
            suite.addTests(tests)

        with open(test_output_file, "w") as f:
            JSONTestRunner(stream=f).run(suite)

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print "Please invoke with one argument: the result json to write."
        print "(This test file assumes it's in the same directory as the code to be tested."
        exit(1)

    run_tests(test_output_file=sys.argv[1])

