# -*- coding: utf8 -*-
#%%
import numpy as np
import pydrake
import os

from pydrake.common import AddResourceSearchPath, FindResourceOrThrow
from pydrake.geometry import SceneGraph
from pydrake.multibody.multibody_tree import (UniformGravityFieldElement,
                                              WeldJoint,)
from pydrake.multibody.multibody_tree.multibody_plant import MultibodyPlant
from pydrake.multibody.multibody_tree.parsing import AddModelFromSdfFile
from pydrake.systems.framework import DiagramBuilder
from pydrake.systems.analysis import Simulator
from underactuated.meshcat_visualizer import MeshcatVisualizer
from pydrake.util.eigen_geometry import Isometry3
from pydrake.math import RollPitchYaw

from pydrake.systems.primitives import SignalLogger


def render_system_with_graphviz(system, output_file="system_view.gz"):
    ''' Renders the Drake system (presumably a diagram,
    otherwise this graph will be fairly trivial) using
    graphviz to a specified file. '''
    from graphviz import Source
    string = system.GetGraphvizString()
    src = Source(string)
    src.render(output_file, view=False)

table_top_z_in_world = 0.736 + 0.057 / 2

'''
apple_initial_position_in_world_frame: numpy array of shape (3,)
    the initial position of the apple's body frame (as defined in its .sdf file) 
    in world frame.
    
robot_initial_joint_angles: numpy array of shape(7,)
    initial joint angles of the robot arm. 
    
sim_duration: float
    simulation duration, expressed in seconds.
    
real_time_rate: float
    1 means as fast as real time. 
    2 means twice as fast as real time.
    0.5 means half as fast as real time.
    0. means simualte as fast as possible. 
'''
def SimulateRobotFreeFall(
        apple_initial_position_in_world_frame,
        robot_initial_joint_angles,
        sim_duration=4.0, real_time_rate=1.0, is_test=False):

    if not is_test:
        print "Warning: if you have not yet run meshcat-server in another " \
              "terminal, this will hang."

    iiwa_sdf_path = os.path.join(
        pydrake.getDrakePath(),
        "manipulation", "models", "iiwa_description", "sdf",
        "iiwa14_no_collision_floating.sdf")

    wsg50_sdf_path = os.path.join(
        pydrake.getDrakePath(),
        "manipulation", "models", "wsg_50_description", "sdf",
        "schunk_wsg_50.sdf")

    table_sdf_path = os.path.join(
        pydrake.getDrakePath(),
        "examples", "kuka_iiwa_arm", "models", "table",
        "extra_heavy_duty_table_surface_only_collision.sdf")

    apple_sdf_path = os.path.join(pydrake.getDrakePath(),
        "examples", "kuka_iiwa_arm", "models", "objects", "apple.sdf")

    # construct multibodyplant
    timestep = 0.0002
    mbp = MultibodyPlant(timestep)
    scene_graph = SceneGraph()

    # Add models
    iiwa_model = AddModelFromSdfFile(
        file_name=iiwa_sdf_path, model_name='robot',
        scene_graph=scene_graph, plant=mbp)
    gripper_model = AddModelFromSdfFile(
        file_name=wsg50_sdf_path, model_name='gripper',
        scene_graph=scene_graph, plant=mbp)
    table_model = AddModelFromSdfFile(
        file_name=table_sdf_path, model_name='table',
        scene_graph=scene_graph, plant=mbp)
    table2_model = AddModelFromSdfFile(
        file_name=table_sdf_path, model_name='table2',
        scene_graph=scene_graph, plant=mbp)
    apple_model = AddModelFromSdfFile(
        file_name=apple_sdf_path, model_name='apple',
        scene_graph=scene_graph, plant=mbp)

    # Define weld(fixed) joints
    X_EeGripper = Isometry3.Identity()
    X_EeGripper.set_translation([0, 0, 0.081])
    X_EeGripper.set_rotation(RollPitchYaw(np.pi/2, 0, np.pi/2).ToRotationMatrix().matrix())

    mbp.AddJoint(
        WeldJoint(name="weld_gripper_to_robot_ee",
        parent_frame_P=mbp.GetBodyByName(
            "iiwa_link_7", iiwa_model).body_frame(),
        child_frame_C=mbp.GetBodyByName(
            "body", gripper_model).body_frame(),
        X_PC=X_EeGripper))

    mbp.AddJoint(
        WeldJoint(name="weld_table_to_world",
        parent_frame_P=mbp.world_body().body_frame(),
        child_frame_C=mbp.GetBodyByName(
            "link", table_model).body_frame(),
        X_PC=Isometry3.Identity()))

    X_WRobot = Isometry3.Identity()
    X_WRobot.set_translation([0, 0, table_top_z_in_world])
    mbp.AddJoint(
        WeldJoint(name="weld_robot_to_world",
        parent_frame_P=mbp.world_body().body_frame(),
        child_frame_C=mbp.GetBodyByName(
            "iiwa_link_0", iiwa_model).body_frame(),
        X_PC=X_WRobot))

    X_WTable2 = Isometry3.Identity()
    X_WTable2.set_translation([0.8, 0, 0])
    mbp.AddJoint(
        WeldJoint(name='weld_table2_to_world',
        parent_frame_P=mbp.world_body().body_frame(),
        child_frame_C=mbp.GetBodyByName("link", table2_model).body_frame(),
        X_PC=X_WTable2))

    # Add gravity
    mbp.AddForceElement(UniformGravityFieldElement([0, 0, -9.81]))

    mbp.Finalize(scene_graph)
    assert mbp.geometry_source_is_registered()

#%% Build drake diagram

    # Drake diagram
    builder = DiagramBuilder()
    builder.AddSystem(scene_graph)
    builder.AddSystem(mbp)

    # Add meshcat visualizer if not in test mode
    viz = None
    if not is_test:
        viz = MeshcatVisualizer(scene_graph)
        builder.AddSystem(viz)
        builder.Connect(scene_graph.get_pose_bundle_output_port(),
                        viz.get_input_port(0))

    # Connect scene_graph to MBP for collision detection.
    builder.Connect(
        mbp.get_geometry_poses_output_port(),
        scene_graph.get_source_pose_port(mbp.get_source_id()))
    builder.Connect(
        scene_graph.get_query_output_port(),
        mbp.get_geometry_query_input_port())

    # Add logger
    state_log = builder.AddSystem(SignalLogger(mbp.get_continuous_state_output_port().size()))
    state_log._DeclarePeriodicPublish(0.02)
    builder.Connect(mbp.get_continuous_state_output_port(), state_log.get_input_port(0))

    # Build diagram.
    diagram = builder.Build()
    if not is_test:
        viz.load()

    # generate system diagram using graphviz if not in test mode
    if not is_test:
        render_system_with_graphviz(diagram, "view.gv")

    # Fix multibodyplant actuation input port to 0.
    diagram_context = diagram.CreateDefaultContext()
    mbp_context = diagram.GetMutableSubsystemContext(
        mbp, diagram_context)

    # fix actuation input of iiwa
    mbp_context.FixInputPort(
        mbp.get_input_port(0).get_index(),
        np.zeros(mbp.get_input_port(0).size()))

    # fix actuation input of gripper
    mbp_context.FixInputPort(
        mbp.get_input_port(1).get_index(),
        np.zeros(mbp.get_input_port(1).size()))

    # set initial pose for the apple.
    X_WApple = Isometry3.Identity()
    X_WApple.set_translation(apple_initial_position_in_world_frame)
    mbt = mbp.model()
    mbt.SetFreeBodyPoseOrThrow(
        mbp.GetBodyByName("base_link_apple", apple_model), X_WApple, mbp_context)

    # set initial posture of the iiwa arm.
    for i, joint_angle in enumerate(robot_initial_joint_angles):
        iiwa_joint = mbp.GetJointByName("iiwa_joint_%d"%(i+1))
        iiwa_joint.set_angle(context=mbp_context, angle=joint_angle)

    simulator = Simulator(diagram, diagram_context)
    simulator.set_publish_every_time_step(False)
    simulator.set_target_realtime_rate(real_time_rate)
    simulator.Initialize()

    # Run simulation
    simulator.StepTo(sim_duration)

    return state_log, mbp

'''
Put your initial guesses here:
your_apple_initial_position_in_world_frame: np array of shape (3,)
your_robot_initial_joint_angles: np array of shape (7,)
'''
your_apple_initial_position_in_world_frame = np.array([-0.2, -0.2, 2.])
your_robot_initial_joint_angles = np.zeros(7)
your_robot_initial_joint_angles[0] = np.pi



