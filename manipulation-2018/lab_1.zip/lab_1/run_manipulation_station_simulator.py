from manipulation_station_simulator import ManipulationStationSimulator

import numpy as np
from pydrake.multibody import inverse_kinematics
from pydrake.trajectories import (
    PiecewisePolynomial
)
from pydrake.util.eigen_geometry import Isometry3
from pydrake.math import RollPitchYaw, RotationMatrix
from robot_plans import *

from pydrake.common import FindResourceOrThrow


'''
Ea, or End_Effector_world_aligned is a frame fixed w.r.t the gripper.
Ea has the same origin as the end effector's body frame, but
its axes are aligned with those of the world frame when the system
has zero state, i.e. the robot is upright with all joint angles
equal to zero.

This frame is defined so that it is convenient to define end effector orientation
relative to the world frame using RollPitchYaw.
'''
def GetEndEffectorWorldAlignedFrame():
    X_EEa = Isometry3.Identity()
    X_EEa.set_rotation(np.array([[0., 1., 0,],
                                 [0, 0, 1],
                                 [1, 0, 0]]))
    return X_EEa

# home position of point Q in world frame.
p_WQ_home = np.array([0.5, 0, 0.5])

# position of point Q in EE frame.  Point Q is fixed in the EE frame.
p_EQ = GetEndEffectorWorldAlignedFrame().multiply(np.array([0., 0., 0.09]))


def GenerateIiwaPlansAndGripperSetPoints(manip_station_sim, q0_kuka, is_printing=True):
    plant = manip_station_sim.plant
    tree = plant.tree()
    iiwa_model = plant.GetModelInstanceByName("iiwa")
    gripper_model = plant.GetModelInstanceByName("gripper")

    # get first pre-pre-grasp pose
    ik_scene = inverse_kinematics.InverseKinematics(plant)
    world_frame = plant.world_frame()
    gripper_frame = plant.GetFrameByName("body", gripper_model)

    theta_bound = 0.005 * np.pi # 0.9 degrees
    X_EEa = GetEndEffectorWorldAlignedFrame()
    R_WEa_ref = RollPitchYaw(0, np.pi*3/4, 0).ToRotationMatrix()
    R_EEa = RotationMatrix(X_EEa.rotation())

    ik_scene.AddOrientationConstraint(
        frameAbar=world_frame, R_AbarA=R_WEa_ref,
        frameBbar=gripper_frame, R_BbarB=R_EEa,
        theta_bound=theta_bound)

    p_WQ_lower = p_WQ_home - 0.01
    p_WQ_upper = p_WQ_home + 0.01
    ik_scene.AddPositionConstraint(
        frameB=gripper_frame, p_BQ=p_EQ,
        frameA=world_frame,
        p_AQ_lower=p_WQ_lower, p_AQ_upper=p_WQ_upper)

    prog = ik_scene.prog()
    prog.SetInitialGuess(ik_scene.q(), np.zeros(plant.num_positions()))
    result = prog.Solve()
    if is_printing:
        print result
    q_val_0 = prog.GetSolution(ik_scene.q())

    # q returned by IK consists of the configuration of all bodies, including
    # the iiwa arm, the box, the gripper and the bottle.
    # But the trajectory sent to iiwa only needs the configuration of iiwa.
    # This function takes in an array of shape (n, plant.num_positions()),
    # and returns an array of shape (n, 7), which only has the configuration of the iiwa arm.
    def GetKukaQKnots(q_knots):
        if len(q_knots.shape) == 1:
            q_knots.resize(1, q_knots.size)
        n = q_knots.shape[0]
        q_knots_kuka = np.zeros((n, 7))
        for i, q_knot in enumerate(q_knots):
            q_knots_kuka[i] = tree.get_positions_from_array(iiwa_model, q_knot)

        return q_knots_kuka

    # q0_kuka to home
    t_knots = np.array([0., 5.0, 10.0])
    q_knots_kuka = np.zeros((3,7))
    q_knots_kuka[0] = q0_kuka
    q_knots_kuka[2] = GetKukaQKnots(q_val_0)
    q_knots_kuka[1] = (q_knots_kuka[0] + q_knots_kuka[2])/2
    qtraj_a2b = PiecewisePolynomial.Cubic(
        t_knots, q_knots_kuka.T,
        np.zeros(7), np.zeros(7))

    q_knots_kuka2 = np.zeros((3,7))
    q_knots_kuka2[2] = q_knots_kuka[0]
    q_knots_kuka2[1] = q_knots_kuka[1]
    q_knots_kuka2[0] = q_knots_kuka[2]
    qtraj_b2a = PiecewisePolynomial.Cubic(
        t_knots, q_knots_kuka2.T,
        np.zeros(7), np.zeros(7))

    def InterpolateStraightLine(p_WQ_start, p_WQ_end, num_knot_points, i):
        return (p_WQ_end - p_WQ_start)/num_knot_points*(i+1) + p_WQ_start

    # inverse_kin_ponitwise
    def GoFromPointToPoint(p_WQ_start, p_WQ_end, duration,
                           num_knot_points,
                           q_initial_guess, InterpolatePosition=InterpolateStraightLine):
        # The first knot point is the zero posture.
        # The second knot is the pre-pre-grasp posture q_val_0
        # The rest are solved for in the for loop below.
        # The hope is that using more knot points makes the trajectory
        # smoother.
        q_knots = np.zeros((num_knot_points+1, plant.num_positions()))
        q_knots[0] = q_initial_guess

        for i in range(num_knot_points):
            ik = inverse_kinematics.InverseKinematics(plant)
            q_variables = ik.q()

            ik.AddOrientationConstraint(
                frameAbar=world_frame, R_AbarA=R_WEa_ref,
                frameBbar=gripper_frame, R_BbarB=R_EEa,
                theta_bound=theta_bound)

            p_WQ = InterpolatePosition(p_WQ_start, p_WQ_end, num_knot_points, i)

            ik.AddPositionConstraint(
                frameB=gripper_frame, p_BQ=p_EQ,
                frameA=world_frame,
                p_AQ_lower=p_WQ-0.005, p_AQ_upper=p_WQ+0.005)

            prog = ik.prog()
            # use the robot posture at the previous knot point as
            # an initial guess.
            prog.SetInitialGuess(q_variables, q_knots[i])
            result = prog.Solve()
            if is_printing:
                print i, ": ", result
            q_knots[i+1] = prog.GetSolution(q_variables)

        t_knots = np.linspace(0, duration, num_knot_points + 1)

        q_knots_kuka = GetKukaQKnots(q_knots)
        qtraj = PiecewisePolynomial.Cubic(
            t_knots, q_knots_kuka.T,
            np.zeros(7), np.zeros(7))

        return qtraj, q_knots


    q_traj_list = [qtraj_a2b, qtraj_b2a]

    plan_list = []
    for q_traj in q_traj_list:
        plan_list.append(JointSpacePlan(q_traj))

    gripper_setpoint_list = [0.05, 0.05]
    return plan_list, gripper_setpoint_list


if __name__ == '__main__':
    is_hardware = False
    object_file_path = FindResourceOrThrow(
            "drake/external/models_robotlocomotion/ycb_objects/061_foam_brick.sdf")

    manip_station_sim = ManipulationStationSimulator(
        time_step=1e-3,
        object_file_path=object_file_path,
        object_base_link_name="base_link",
        is_hardware=is_hardware)

    q0 = [0, 0.6-np.pi/6, 0, -1.75, 0, 1.0, 0]

    plan_list, gripper_setpoint_list = \
        GenerateIiwaPlansAndGripperSetPoints(manip_station_sim, q0)

    if is_hardware:
        iiwa_position_command_log = manip_station_sim.RunRealRobot(plan_list, gripper_setpoint_list)
    else:
        q0[1] += np.pi/6
        iiwa_position_command_log = manip_station_sim.RunSimulation(plan_list, gripper_setpoint_list,
                                        extra_time=2.0, q0_kuka=q0)